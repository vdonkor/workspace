CREATE OR REPLACE VIEW "cloud_storage_metrics_all" AS
select cloud, service_name, application_name, report_date, cast(storage_bytes as bigint) as storage_bytes
from (
		select 'aws' as cloud,
			service_name,
			application_name,
			cast(storage_bytes as bigint) as storage_bytes,
			report_date
		from "aws_account_storage_metrics"
		union all
		select 'azure' as cloud,
			resource_type as service_name,
			subscription_name as application_name,
			cast(storage_bytes as bigint) as storage_bytes,
			report_date
		from "azure_subscription_storage_metrics"
		union all
		select 'on_prem' as cloud,
			'on_prem' as service_name,
			'on_prem' as application_name,
			cast(vm_disk_size_gb as bigint) * parse_presto_data_size('1GB') as storage_bytes,
			report_date
		from "daily_infraview_performancedata_metrics"
	)