CREATE OR REPLACE VIEW "hosting_report_azure_storage_accounts" AS
select count(name) as num_storage_accounts,
	sum(storage_bytes) / parse_presto_data_size('1GB') as storage_gbs
from current_azure_storage_accounts