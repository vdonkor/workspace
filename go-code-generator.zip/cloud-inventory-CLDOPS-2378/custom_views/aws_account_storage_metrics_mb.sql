CREATE OR REPLACE VIEW "aws_account_storage_metrics_mb" AS
select q_service.service_name,
	q_service.storage_mb,
	q_service.account_id,
	q_accounts.application_name,
	q_accounts.environment,
	q_accounts.customer_managed,
	q_accounts.devsecops_managed,
	q_accounts.ncc_managed,
	q_accounts.management_model,
	q_service.report_date
from (
		(
			select 'ebs' as service_name,
				report_date,
				size * parse_presto_data_size('1GB') / parse_presto_data_size('1MB') as storage_mb,
				account_id
			from daily_aws_ec2_volumes
            where report_date = (current_date - interval '1' day)
		)
		union all
		(
			select 'dynamodb' as service_name,
				report_date,
				table_size_bytes / parse_presto_data_size('1MB') as storage_mb,
				account_id
			from daily_aws_dynamodb_tables
            where report_date = (current_date - interval '1' day)
		)
		union all
		(
			select 'cloudwatch_logs' as service_name,
				report_date,
				stored_bytes / parse_presto_data_size('1MB') as storage_mb,
				account_id
			from daily_aws_cloudwatchlogs_log_groups
            where report_date = (current_date - interval '1' day)
		)
		union all
		(
			select 'efs' as service_name,
				report_date,
				size_in_bytes.value / parse_presto_data_size('1MB') as storage_mb,
				account_id
			from daily_aws_efs_filesystems
            where report_date = (current_date - interval '1' day)
		)
		union all
		(
			select 'rds' as service_name,
				report_date,
				allocated_storage * parse_presto_data_size('1GB') / parse_presto_data_size('1MB') as storage_mb,
				account_id
			from (daily_aws_rds_db_instances)
            where report_date = (current_date - interval '1' day)
		)
		union all
		(
			select 'redshift' as service_name,
				report_date,
				total_storage_capacity_in_mega_bytes * parse_presto_data_size('1MB') / parse_presto_data_size('1MB') as storage_mb,
				account_id
			from daily_aws_redshift_clusters
            where report_date = (current_date - interval '1' day)
		)
		union all
		(
			select 's3' as service_name,
				dt - interval '1' day as report_date,
				metric_value / parse_presto_data_size('1MB') as storage_mb,
				aws_account_number as account_id
			from storage_lens_metrics
			where metric_name = 'StorageBytes'
				and record_type = 'ACCOUNT'
                and dt = (current_date - interval '1' day)
		)
	) q_service
	join (
		select *
		from daily_custom_accountinventory_accounts
	) q_accounts on q_service.account_id = q_accounts.account_id
	and q_service.report_date = q_accounts.report_date