CREATE OR REPLACE VIEW "aws_account_storage_metrics" AS
select q_service.service_name,
	q_service.storage_bytes,
	q_service.account_id,
	q_accounts.application_name,
	q_accounts.environment,
	q_accounts.customer_managed,
	q_accounts.devsecops_managed,
	q_accounts.ncc_managed,
	q_accounts.management_model,
	q_service.report_date
from (
		(
			select 'ebs' as service_name,
				report_date,
				size * parse_presto_data_size('1GB') as storage_bytes,
				account_id
			from daily_aws_ec2_volumes
		)
		union all
		(
			select 'dynamodb' as service_name,
				report_date,
				table_size_bytes as storage_bytes,
				account_id
			from daily_aws_dynamodb_tables
		)
		union all
		(
			select 'cloudwatch_logs' as service_name,
				report_date,
				stored_bytes as storage_bytes,
				account_id
			from daily_aws_cloudwatchlogs_log_groups
		)
		union all
		(
			select 'efs' as service_name,
				report_date,
				size_in_bytes.value as storage_bytes,
				account_id
			from daily_aws_efs_filesystems
		)
		union all
		(
			select 'rds' as service_name,
				report_date,
				allocated_storage * parse_presto_data_size('1GB') as storage_bytes,
				account_id
			from (daily_aws_rds_db_instances)
		)
		union all
		(
			select 'redshift' as service_name,
				report_date,
				total_storage_capacity_in_mega_bytes * parse_presto_data_size('1MB') as storage_bytes,
				account_id
			from daily_aws_redshift_clusters
		)
		union all
		(
			select 's3' as service_name,
				dt + interval '1' day as report_date,
				metric_value as storage_bytes,
				aws_account_number as account_id
			from storage_lens_metrics
			where metric_name = 'StorageBytes'
				and record_type = 'ACCOUNT'
		)
	) q_service
	join (
		select *
		from daily_custom_accountinventory_accounts
	) q_accounts on q_service.account_id = q_accounts.account_id
	and q_service.report_date = q_accounts.report_date