CREATE OR REPLACE VIEW current_storage_lens_metrics AS 
WITH
  filter AS (
   SELECT
     *
   , "max"(dt) OVER (PARTITION BY dt) newest_report_date
   FROM
     storage_lens_metrics
   WHERE (dt >= current_date - interval '3' day)
) 
SELECT *
FROM
  filter
WHERE (dt = newest_report_date)