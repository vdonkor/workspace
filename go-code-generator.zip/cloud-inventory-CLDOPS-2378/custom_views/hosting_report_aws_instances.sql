CREATE OR REPLACE VIEW "hosting_report_aws_instances" AS
select case
		q_accounts.ncc_managed
		when false then 'customer_managed' else 'ncc_managed'
	end as management_model,
	q_ec2.platform,
	count(q_ec2.instance_id) as num_vms
from (
		select instance_id,
			case
				when tags [ 'is-appliance' ] = 'yes' then 'appliance'
				when platform = 'windows' then 'windows' else 'linux'
			end as platform,
			account_id
		from current_aws_ec2_instances
		where state.name = 'running'
	) q_ec2
	join (
		select account_id,
			ncc_managed
		from current_custom_accountinventory_accounts
	) q_accounts on q_ec2.account_id = q_accounts.account_id
group by q_accounts.ncc_managed,
	q_ec2.platform
order by q_accounts.ncc_managed,
	q_ec2.platform