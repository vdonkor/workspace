CREATE OR REPLACE VIEW "azure_subscription_compute_metrics" AS
select q_service.service_name,
	q_service.subscription_id,
	q_sub.display_name as subscription_name,
	q_service.resource_group,
	q_service.location,
	q_service.power_state,
	q_service.vcpus,
	q_service.memory_gbs,
	q_service.report_date
from (
		(
			select 'vms' as service_name,
				q_vm.location,
				q_vm.subscription_id,
				q_vm.resource_group,
				q_vm.power_state,
				q_vm.vm_size,
				q_sku.vcpus,
				q_sku.memory_gbs,
				q_vm.report_date
			from (
					select location,
						virtual_machine_properties.hardware_profile.vm_size as vm_size,
						subscription_id,
						resource_group,
						power_state,
						report_date
					from daily_azure_compute_virtual_machines
				) q_vm
				join (
					select name,
						cast(capabilities [ 'vCPUs' ] as double) as vcpus,
						cast(capabilities [ 'MemoryGB' ] as double) as memory_gbs,
						report_date
					from daily_azure_compute_resource_skus
					where resource_type = 'virtualMachines'
				) q_sku on q_vm.vm_size = q_sku.name
				and q_vm.report_date = q_sku.report_date
		)
		union all
		(
			select 'scale_set_vms' as service_name,
				q_vm.location,
				q_vm.subscription_id,
				q_vm.resource_group,
				q_vm.power_state,
				q_vm.vm_size,
				q_sku.vcpus,
				q_sku.memory_gbs,
				q_vm.report_date
			from (
					select location,
						sku.name as vm_size,
						subscription_id,
						resource_group,
						power_state,
						report_date
					from daily_azure_compute_virtual_machine_scale_set_vms
				) q_vm
				join (
					select name,
						cast(capabilities [ 'vCPUs' ] as double) as vcpus,
						cast(capabilities [ 'MemoryGB' ] as double) as memory_gbs,
						report_date
					from daily_azure_compute_resource_skus
					where resource_type = 'virtualMachines'
				) q_sku on q_vm.vm_size = q_sku.name
				and q_vm.report_date = q_sku.report_date
		)
	) q_service
	join (
		select subscription_id,
			display_name,
			report_date
		from daily_azure_subscription_subscriptions
	) q_sub on q_service.subscription_id = q_sub.subscription_id
	and q_service.report_date = q_sub.report_date