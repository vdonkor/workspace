CREATE OR REPLACE VIEW "hosting_report_aws_volumes" AS
select case
		q_accounts.ncc_managed
		when false then 'customer_managed' else 'ncc_managed'
	end as management_model,
	count(q_ebs.volume_id) as num_volumes,
	sum(q_ebs.size) as total_size_gb
from (
		select volume_id,
			size,
			account_id
		from current_aws_ec2_volumes
	) q_ebs
	join (
		select account_id,
			ncc_managed
		from current_custom_accountinventory_accounts
	) q_accounts on q_ebs.account_id = q_accounts.account_id
group by q_accounts.ncc_managed
order by q_accounts.ncc_managed