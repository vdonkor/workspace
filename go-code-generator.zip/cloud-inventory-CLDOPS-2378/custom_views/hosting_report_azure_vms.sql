CREATE OR REPLACE VIEW "hosting_report_azure_vms" AS
select q_vm.os_type,
	count(q_vm.name) as num_vms
from (
		select 'vm' as vm_type,
			power_state,
			name,
			virtual_machine_properties.storage_profile.os_disk.os_type
		from current_azure_compute_virtual_machines
		union all
		select 'scale_set_vm' as vm_type,
			power_state,
			name,
			virtual_machine_scale_set_vm_properties.storage_profile.os_disk.os_type
		from current_azure_compute_virtual_machine_scale_set_vms
	) q_vm
where q_vm.power_state = 'running'
group by q_vm.os_type
order by q_vm.os_type