CREATE OR REPLACE VIEW "aws_account_resource_counts" AS
select q_service.resource_name,
	q_service.account_id,
	q_service.count,
	q_accounts.application_name,
	q_accounts.environment,
	q_accounts.customer_managed,
	q_accounts.devsecops_managed,
	q_accounts.ncc_managed,
	q_accounts.management_model,
	q_service.report_date
from (
		(
			(
				select 'accounts' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_custom_accountinventory_accounts
				group by account_id,
					report_date
			)
			union all
			(
				select 'cloudwatch_log_groups' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_cloudwatchlogs_log_groups
				group by account_id,
					report_date
			)
			union all
			(
				select 'dynamodb_tables' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_dynamodb_tables
				group by account_id,
					report_date
			)
			union all
			(
				select 'ec2_instances' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_ec2_instances
				group by account_id,
					report_date
			)
			union all
			(
				select 'ec2_vpcs' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_ec2_vpcs
				group by account_id,
					report_date
			)
			union all
			(
				select 'ec2_volumes' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_ec2_volumes
				group by account_id,
					report_date
			)
			union all
			(
				select 'ecs_clusters' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_ecs_clusters
				group by account_id,
					report_date
			)
			union all
			(
				select 'ecs_services' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_ecs_services
				group by account_id,
					report_date
			)
			union all
			(
				select 'ecs_tasks' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_ecs_tasks
				group by account_id,
					report_date
			)
			union all
			(
				select 'efs_filesystems' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_efs_filesystems
				group by account_id,
					report_date
			)
			union all
			(
				select 'elb_classic_load_balancers' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_elasticloadbalancing_load_balancers
				group by account_id,
					report_date
			)
			union all
			(
				select 'elb_application_load_balancers' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_elasticloadbalancingv2_load_balancers
				where type = 'application'
				group by account_id,
					report_date
			)
			union all
			(
				select 'elb_network_load_balancers' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_elasticloadbalancingv2_load_balancers
				where type = 'network'
				group by account_id,
					report_date
			)
			union all
			(
				select 'lambda_functions' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_lambda_functions
				group by account_id,
					report_date
			)
			union all
			(
				select 'rds_db_instances' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_rds_db_instances
				group by account_id,
					report_date
			)
			union all
			(
				select 'redshift_clusters' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_redshift_clusters
				group by account_id,
					report_date
			)
			union all
			(
				select 's3_buckets' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_s3_buckets
				group by account_id,
					report_date
			)
			union all
			(
				select 'sns_topics' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_sns_topics
				group by account_id,
					report_date
			)
			union all
			(
				select 'sqs_queues' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_sqs_queues
				group by account_id,
					report_date
			)
			union all
			(
				select 'storagegateway_gateways' as resource_name,
					count() as count,
					account_id,
					report_date
				from daily_aws_storagegateway_gateways
				group by account_id,
					report_date
			)
		)
	) q_service
	join (
		select *
		from daily_custom_accountinventory_accounts
	) q_accounts on q_service.account_id = q_accounts.account_id
	and q_service.report_date = q_accounts.report_date