CREATE OR REPLACE VIEW "hosting_report_aws_buckets" AS
SELECT case
		q_accounts.ncc_managed
		when false then 'customer_managed' else 'ncc_managed'
	end as management_model,
	count(q_s3.name) as num_buckets,
	sum(q_storage_lens.storage_bytes) / parse_presto_data_size('1TB') as total_size_tb
FROM (
		(
			SELECT name,
				account_id
			FROM current_aws_s3_buckets
		) q_s3
		INNER JOIN (
			SELECT bucket_name,
				"max"(
					(
						CASE
							WHEN (metric_name = 'StorageBytes') THEN metric_value ELSE 0
						END
					)
				) storage_bytes,
				"max"(
					(
						CASE
							WHEN (metric_name = 'ObjectCount') THEN metric_value ELSE 0
						END
					)
				) object_count
			FROM current_storage_lens_metrics
			GROUP BY bucket_name
		) q_storage_lens ON (q_s3.name = q_storage_lens.bucket_name)
	)
	INNER join (
		select account_id,
			ncc_managed
		from current_custom_accountinventory_accounts
	) q_accounts on q_s3.account_id = q_accounts.account_id
group by q_accounts.ncc_managed
order by q_accounts.ncc_managed