CREATE OR REPLACE VIEW "aws_containerized_accounts" AS
SELECT A.account_id,
application_name,
environment,
cloud_id,
customer_managed,
devsecops_managed,
ncc_managed,
gitlab_project_url,
management_model,
report_time,
report_date,
oldest_report_time
FROM (
    SELECT *, "max"(report_time) OVER (PARTITION BY report_date) oldest_report_time
    FROM custom_accountinventory_accounts WHERE (report_date = current_date)
    ) AS A
RIGHT JOIN (
    SELECT account_id
    FROM "cloud-inventory"."current_custom_meta_aws_resource_summary"
    WHERE (service = 'ecs' OR service = 'eks') AND count > 0
    GROUP BY account_id
) AS B
ON A.account_id = B.account_id
WHERE (report_time = oldest_report_time)