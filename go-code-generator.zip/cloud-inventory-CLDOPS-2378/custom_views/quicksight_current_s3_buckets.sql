CREATE OR REPLACE VIEW quicksight_current_s3_buckets AS 
select q_s3.*,
	q_storage_lens.storage_bytes,
	q_storage_lens.object_count,
	q_storage_lens.replicated_storage_bytes,
	q_storage_lens.replicated_object_count,
	q_storage_lens.encrypted_storage_bytes,
	q_storage_lens.encrypted_object_count,
	q_storage_lens.delete_marker_object_count,
	q_storage_lens.object_lock_enabled_storage_bytes,
	q_storage_lens.object_lock_enabled_object_count,
	q_storage_lens.current_version_storage_bytes,
	q_storage_lens.current_version_object_count,
	q_storage_lens.non_current_version_storage_bytes,
	q_storage_lens.non_current_version_object_count,
	q_storage_lens.incomplete_multipart_upload_storage_bytes,
	q_storage_lens.incomplete_multipart_upload_object_count,
    q_account.application_name,
	q_account.environment,
	q_account.customer_managed,
	q_account.devsecops_managed,
	q_account.ncc_managed,
	q_account.management_model
from (
		select name,
			account_id,
			region,
			is_public,
			versioning_status,
			mfa_delete_status
		from current_aws_s3_buckets
	) q_s3
	join (
		select bucket_name,
			max(
				case
					when metric_name = 'StorageBytes' then metric_value else 0
				end
			) as storage_bytes,
			max(
				case
					when metric_name = 'ObjectCount' then metric_value else 0
				end
			) as object_count,
			max(
				case
					when metric_name = 'ReplicatedStorageBytes' then metric_value else 0
				end
			) as replicated_storage_bytes,
			max(
				case
					when metric_name = 'ReplicatedObjectCount' then metric_value else 0
				end
			) as replicated_object_count,
			max(
				case
					when metric_name = 'EncryptedStorageBytes' then metric_value else 0
				end
			) as encrypted_storage_bytes,
			max(
				case
					when metric_name = 'EncryptedObjectCount' then metric_value else 0
				end
			) as encrypted_object_count,
			max(
				case
					when metric_name = 'DeleteMarkerObjectCount' then metric_value else 0
				end
			) as delete_marker_object_count,
			max(
				case
					when metric_name = 'ObjectLockEnabledStorageBytes' then metric_value else 0
				end
			) as object_lock_enabled_storage_bytes,
			max(
				case
					when metric_name = 'ObjectLockEnabledObjectCount' then metric_value else 0
				end
			) as object_lock_enabled_object_count,
			max(
				case
					when metric_name = 'CurrentVersionStorageBytes' then metric_value else 0
				end
			) as current_version_storage_bytes,
			max(
				case
					when metric_name = 'CurrentVersionObjectCount' then metric_value else 0
				end
			) as current_version_object_count,
			max(
				case
					when metric_name = 'NonCurrentVersionStorageBytes' then metric_value else 0
				end
			) as non_current_version_storage_bytes,
			max(
				case
					when metric_name = 'NonCurrentVersionObjectCount' then metric_value else 0
				end
			) as non_current_version_object_count,
			max(
				case
					when metric_name = 'IncompleteMultipartUploadStorageBytes' then metric_value else 0
				end
			) as incomplete_multipart_upload_storage_bytes,
			max(
				case
					when metric_name = 'IncompleteMultipartUploadObjectCount' then metric_value else 0
				end
			) as incomplete_multipart_upload_object_count
		from current_storage_lens_metrics
		group by bucket_name
	) q_storage_lens on q_s3.name = q_storage_lens.bucket_name
    join (
		select *
		from current_custom_accountinventory_accounts
	) q_account on q_s3.account_id = q_account.account_id