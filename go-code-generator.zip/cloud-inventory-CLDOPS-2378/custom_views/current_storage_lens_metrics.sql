CREATE OR REPLACE VIEW current_storage_lens_metrics AS WITH filter AS (
		SELECT *,
			"max"(dt) OVER () newest_report_date
		FROM storage_lens_metrics
		WHERE (dt >= (current_date - INTERVAL '3' DAY))
	)
SELECT *
FROM filter
WHERE (dt = newest_report_date)