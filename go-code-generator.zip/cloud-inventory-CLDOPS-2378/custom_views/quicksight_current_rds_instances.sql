CREATE OR REPLACE VIEW quicksight_current_rds_instances AS 
select q_rds.*,
	q_account.application_name,
	q_account.environment,
	q_account.customer_managed,
	q_account.devsecops_managed,
	q_account.ncc_managed,
	q_account.management_model
from (
		select allocated_storage,
			db_cluster_identifier,
			db_instance_class,
			db_instance_identifier,
			db_instance_status,
			db_name,
			deletion_protection,
			engine,
			engine_version,
			iops,
			license_model,
			max_allocated_storage,
			multi_az,
			storage_encrypted,
			storage_type,
			region,
			account_id
			from current_aws_rds_db_instances
	) q_rds
	join (
		select *
		from current_custom_accountinventory_accounts
	) q_account on q_rds.account_id = q_account.account_id