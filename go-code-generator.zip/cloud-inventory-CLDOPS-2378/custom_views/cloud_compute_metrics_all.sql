CREATE OR REPLACE VIEW "cloud_compute_metrics_all" AS
select *
from (
		select 'aws' as cloud,
			service_name,
			application_name,
			state,
			vcpus,
			memory_gbs,
			report_date
		from "aws_account_compute_metrics"
		union all
		select 'azure' as cloud,
			service_name,
			subscription_name as application_name,
			power_state as state,
			vcpus,
			memory_gbs,
			report_date
		from "azure_subscription_compute_metrics"
		union all
		select 'on_prem' as cloud,
			'on_prem' as service_name,
			'on_prem' as application_name,
			'running' as state,
			vm_cores as vcpus,
			vm_memory_gb as memory_gbs,
			report_date
		from "daily_infraview_performancedata_metrics"
	)