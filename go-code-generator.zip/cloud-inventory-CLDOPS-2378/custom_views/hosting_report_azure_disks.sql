CREATE OR REPLACE VIEW "hosting_report_azure_disks" AS
select count(name) as num_disks,
	sum(cast(disk_properties.disk_size_bytes as double)) / parse_presto_data_size('1GB') as storage_gbs
from current_azure_compute_disks