CREATE OR REPLACE VIEW quicksight_current_ec2_volumes AS 
SELECT
  q_ebs.*
, q_account.application_name
, q_account.environment
, q_account.customer_managed
, q_account.devsecops_managed
, q_account.ncc_managed
, q_account.management_model
FROM
  ((
   SELECT
     availability_zone
   , encrypted
   , fast_restored
   , iops
   , multi_attach_enabled
   , snapshot_id
   , state
   , throughput
   , volume_id
   , volume_type
   , region
   , account_id
   , (CASE WHEN ("cardinality"(attachments) > 0) THEN true ELSE false END) is_attached
   FROM
     current_aws_ec2_volumes
)  q_ebs
INNER JOIN (
   SELECT *
   FROM
     current_custom_accountinventory_accounts
)  q_account ON (q_ebs.account_id = q_account.account_id))
