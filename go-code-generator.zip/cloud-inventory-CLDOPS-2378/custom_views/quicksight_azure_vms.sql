CREATE OR REPLACE VIEW quicksight_azure_vms AS 
select q_sub.subscription_id,
	q_sub.display_name as subscription_name,
	q_vm.location,
	q_vm.resource_group,
	q_vm.vm_type,
	q_vm.name,
	q_vm.power_state,
	q_vm.provisioning_state,
	q_vm.platform_update_domain,
	q_vm.platform_fault_domain,
	q_vm.os_type,
	q_sku.vcpus,
	q_sku.memory_gb,
	q_sku.tier,
	q_sku.family,
	q_sku.size
from (
		select 'vm' as vm_type,
			virtual_machine_properties.hardware_profile.vm_size,
			power_state,
			provisioning_state,
			name,
			location,
			virtual_machine_properties.storage_profile.os_disk.os_type,
			subscription_id,
			resource_group,
			virtual_machine_properties.instance_view.platform_update_domain,
			virtual_machine_properties.instance_view.platform_fault_domain
		from current_azure_compute_virtual_machines
		union all
		select 'scale_set_vm' as vm_type,
			sku.name as vm_size,
			power_state,
			provisioning_state,
			name,
			location,
			virtual_machine_scale_set_vm_properties.storage_profile.os_disk.os_type,
			subscription_id,
			resource_group,
			virtual_machine_scale_set_vm_properties.instance_view.platform_update_domain,
			virtual_machine_scale_set_vm_properties.instance_view.platform_fault_domain
		from current_azure_compute_virtual_machine_scale_set_vms
	) q_vm
	join (
		select name,
			cast(capabilities [ 'vCPUs' ] as double) as vcpus,
			cast(capabilities [ 'MemoryGB' ] as double) as memory_gb,
			tier,
			family,
			size
		from current_azure_compute_resource_skus
		where resource_type = 'virtualMachines'
	) q_sku on q_vm.vm_size = q_sku.name
	join (
		select subscription_id,
			display_name
		from current_azure_subscription_subscriptions
	) q_sub on q_vm.subscription_id = q_sub.subscription_id