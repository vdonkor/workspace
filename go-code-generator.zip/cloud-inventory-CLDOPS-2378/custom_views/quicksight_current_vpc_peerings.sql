CREATE OR REPLACE VIEW quicksight_current_vpc_peerings AS 
select q_peering.*,
	q_accepter_account.application_name as accepter_application_name,
	q_accepter_account.environment as accepter_environment,
	q_accepter_account.customer_managed as accepter_customer_managed,
	q_accepter_account.devsecops_managed as accepter_devsecops_managed,
	q_accepter_account.ncc_managed as accepter_ncc_managed,
	q_accepter_account.management_model as accepter_management_model,
	q_requester_account.application_name as requester_application_name,
	q_requester_account.environment as requester_environment,
	q_requester_account.customer_managed as requester_customer_managed,
	q_requester_account.devsecops_managed as requester_devsecops_managed,
	q_requester_account.ncc_managed as requester_ncc_managed,
	q_requester_account.management_model as requester_management_model,
	q_accepter_vpc.vpc_name as accepter_vpc_name,
	q_requester_vpc.vpc_name as requester_vpc_name
from (
		select accepter_vpc_info.owner_id as accepter_account_id,
			accepter_vpc_info.vpc_id as accepter_vpc_id,
			accepter_vpc_info.region as accepter_region,
			requester_vpc_info.owner_id as requester_account_id,
			requester_vpc_info.vpc_id as requester_vpc_id,
			requester_vpc_info.region as requester_region,
			vpc_peering_connection_id
		from current_aws_ec2_vpc_peering_connections
		where requester_vpc_info.owner_id = account_id
	) q_peering
	join (
		select *
		from current_custom_accountinventory_accounts
	) q_accepter_account on q_peering.accepter_account_id = q_accepter_account.account_id
	join (
		select *
		from current_custom_accountinventory_accounts
	) q_requester_account on q_peering.requester_account_id = q_requester_account.account_id
	join (
		select vpc_id,
			tags [ 'Name' ] as vpc_name
		from current_aws_ec2_vpcs
	) q_accepter_vpc on q_peering.accepter_vpc_id = q_accepter_vpc.vpc_id
	join (
		select vpc_id,
			tags [ 'Name' ] as vpc_name
		from current_aws_ec2_vpcs
	) q_requester_vpc on q_peering.requester_vpc_id = q_requester_vpc.vpc_id