CREATE OR REPLACE VIEW quicksight_azure_disks AS 
select q_disks.*,
	q_sub.display_name as subscription_name
from (
		select sku.name as disk_type,
			disk_properties.disk_size_bytes,
			name,
			location,
			resource_group,
			subscription_id
		from current_azure_compute_disks
	) q_disks
	join (
		select subscription_id,
			display_name
		from current_azure_subscription_subscriptions
	) q_sub on q_disks.subscription_id = q_sub.subscription_id