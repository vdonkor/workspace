CREATE OR REPLACE VIEW "aws_account_compute_metrics" AS
select q_service.service_name,
	q_service.vcpus,
	q_service.memory_gbs,
	q_service.state,
	q_service.account_id,
	q_accounts.application_name,
	q_accounts.environment,
	q_accounts.customer_managed,
	q_accounts.devsecops_managed,
	q_accounts.ncc_managed,
	q_accounts.management_model,
	q_service.report_date
from (
		(
			select 'ec2' as service_name,
				cast(q_types.v_cpu_info.default_v_cpus as double) as vcpus,
				cast(q_types.memory_info.size_in_mi_b as double) / 1024 as memory_gbs,
				q_ec2.report_date,
				q_ec2.account_id,
				q_ec2.state.name as state
			from (
					select *
					from daily_aws_ec2_instances
				) q_ec2
				join (
					select *
					from daily_aws_ec2_instance_types
				) q_types on q_ec2.instance_type = q_types.instance_type
				and q_ec2.report_date = q_types.report_date
		)
		union all
		(
			select 'ecs' as service_name,
				cast(cpu as double) / 1024 as vcpus,
				cast(memory as double) / 1024 as memory_gbs,
				report_date,
				account_id,
				'running' as state
			from daily_aws_ecs_tasks
			where last_status = 'RUNNING'
		)
	) q_service
	join (
		select *
		from daily_custom_accountinventory_accounts
	) q_accounts on q_service.account_id = q_accounts.account_id
	and q_service.report_date = q_accounts.report_date