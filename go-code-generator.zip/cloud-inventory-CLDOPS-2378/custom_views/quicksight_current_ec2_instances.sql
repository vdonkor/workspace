CREATE OR REPLACE VIEW quicksight_current_ec2_instances AS
select q_ec2.*,
	q_types.bare_metal,
	q_types.current_generation,
	q_types.memory_info.size_in_mi_b / 1024 as memory_size_gbs,
	q_types.v_cpu_info.default_v_cpus as vcpus,
	split(q_types.instance_type, '.') [ 1 ] as instance_family,
	split(q_types.instance_type, '.') [ 2 ] as instance_size,
	q_subnet.availability_zone,
	q_subnet.availability_zone_id,
	q_subnet.subnet_name,
	q_vpc.vpc_name,
	q_account.application_name,
	q_account.environment,
	q_account.customer_managed,
	q_account.devsecops_managed,
	q_account.ncc_managed,
	q_account.management_model
from (
		select architecture,
			hypervisor,
			instance_type,
			private_ip_address,
			state.name as state,
			case
				when platform = 'windows' then platform else 'linux'
			end as platform,
			subnet_id,
			vpc_id,
			tags [ 'Name' ] as name,
			region,
			account_id
		from current_aws_ec2_instances
	) q_ec2
	join (
		select *
		from current_aws_ec2_instance_types
	) q_types on q_ec2.instance_type = q_types.instance_type
	join (
		select availability_zone,
			availability_zone_id,
			subnet_id,
			tags [ 'Name' ] as subnet_name
		from current_aws_ec2_subnets
	) q_subnet on q_ec2.subnet_id = q_subnet.subnet_id
	join (
		select vpc_id,
			tags [ 'Name' ] as vpc_name
		from current_aws_ec2_vpcs
	) q_vpc on q_ec2.vpc_id = q_vpc.vpc_id
	join (
		select *
		from current_custom_accountinventory_accounts
	) q_account on q_ec2.account_id = q_account.account_id