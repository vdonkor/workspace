CREATE OR REPLACE VIEW "azure_subscription_storage_metrics" AS
select q_service.resource_type,
	q_service.resource_name,
	q_service.storage_bytes,
	q_service.location,
	q_service.resource_group,
	q_service.subscription_id,
	q_service.report_date,
	q_sub.display_name as subscription_name
from (
		(
			select resource_type,
				name as resource_name,
				case
					resource_type
					when 'storage_account_blob' then blob_storage_bytes
					when 'storage_account_queue' then queue_storage_bytes
					when 'storage_account_table' then table_storage_bytes
					when 'storage_account_file' then file_storage_bytes
				end as storage_bytes,
				location,
				resource_group,
				subscription_id,
				report_date
			from (
					select *
					from daily_azure_storage_accounts
				) Y
				cross join (
					select 'storage_account_blob' as resource_type
					union all
					select 'storage_account_queue' as resource_type
					union all
					select 'storage_account_table' as resource_type
					union all
					select 'storage_account_file' as resource_type
				) X
		)
		union all
		(
			select 'compute_disks' as resource_type,
				name as resource_name,
				cast(disk_properties.disk_size_bytes as double) as storage_bytes,
				location,
				resource_group,
				subscription_id,
				report_date
			from daily_azure_compute_disks
		)
	) q_service
	join (
		select subscription_id,
			display_name,
			report_date
		from daily_azure_subscription_subscriptions
	) q_sub on q_service.subscription_id = q_sub.subscription_id
	and q_service.report_date = q_sub.report_date