package main

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"github.com/xitongsys/parquet-go-source/s3v2"
	"github.com/xitongsys/parquet-go/reader"
	"github.com/xitongsys/parquet-go/writer"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/catalog"
)

var (
	parquetS3Viper = viper.New()
	logViper       = viper.New()
)

func initLogOptions() {
	logViper.SetEnvPrefix("log")
	logViper.AutomaticEnv()

	logViper.BindEnv("level")
	logViper.SetDefault("level", "info")

	logViper.BindEnv("caller")
	logViper.SetDefault("caller", false)
}

func initParquetS3Options() {
	parquetS3Viper.SetEnvPrefix("parquet_s3")
	parquetS3Viper.AutomaticEnv()

	parquetS3Viper.BindEnv("bucket")

	parquetS3Viper.BindEnv("path_prefix")
	parquetS3Viper.SetDefault("path_prefix", "parquet/")

	parquetS3Viper.BindEnv("file_extension")
	parquetS3Viper.SetDefault("file_extension", "parquet")

	parquetS3Viper.BindEnv("parquet_pages")
	parquetS3Viper.SetDefault("parquet_pages", 4)
}

func init() {
	initLogOptions()
	initParquetS3Options()
}

func main() {
	baseAwsConfig, err := config.LoadDefaultConfig(context.TODO())
	if err != nil {
		panic(err)
	}

	s3Client := s3.NewFromConfig(baseAwsConfig)

	today := time.Now().UTC()
	yesterday := today.Add(-24 * time.Hour)

	yesterdayDateString := yesterday.Format("2006-01-02")

	date := yesterdayDateString
	logrus.Info("Starting data merge for " + date)

	bucket := parquetS3Viper.GetString("bucket")

	for cloud, services := range catalog.DatasourceModels {
		for service, datasources := range services {
			for datasourceName, model := range datasources {
				filename := fmt.Sprintf("parquet/%s/%s/%s/report_date=%s/merged.parquet", cloud, service, datasourceName, date)
				prefix := fmt.Sprintf("parquet/%s/%s/%s/report_date=%s/", cloud, service, datasourceName, date)

				s3FileWriter, err := s3v2.NewS3FileWriterWithClient(context.TODO(), s3Client, bucket, filename, nil)
				if err != nil {
					panic(err)
				}

				s3ParquetWriter, err := writer.NewParquetWriter(s3FileWriter, model, 4)
				if err != nil {
					panic(err)
				}

				paginator := s3.NewListObjectsV2Paginator(s3Client, &s3.ListObjectsV2Input{
					Bucket: aws.String(bucket),
					Prefix: aws.String(prefix),
				})

				readObjectKeys := []string{}
				foundObjects := false
				for paginator.HasMorePages() {
					page, err := paginator.NextPage(context.TODO())
					if err != nil {
						panic(err)
					}

					for _, object := range page.Contents {
						if strings.HasSuffix(*object.Key, "merged.parquet") {
							continue
						}
						// get parquet reader for object
						objectS3Reader, err := s3v2.NewS3FileReaderWithClient(context.TODO(), s3Client, bucket, *object.Key)
						if err != nil {
							panic(err)
						}

						objectParquetReader, err := reader.NewParquetReader(objectS3Reader, model, 4)
						if err != nil {
							panic(err)
						}

						for i := 0; i < int(objectParquetReader.GetNumRows()); i++ {

							objs, err := objectParquetReader.ReadByNumber(1)
							if err != nil {
								panic(err)
							}

							err = s3ParquetWriter.Write(objs[0])
							if err != nil {
								panic(err)
							}
						}

						objectParquetReader.ReadStop()
						err = objectS3Reader.Close()
						if err != nil {
							panic(err)
						}

						readObjectKeys = append(readObjectKeys, *object.Key)
						foundObjects = true

					}
				}

				if foundObjects {
					err = s3ParquetWriter.WriteStop()
					if err != nil {
						panic(err)
					}

					err = s3FileWriter.Close()
					if err != nil {
						panic(err)
					}

					logrus.WithFields(logrus.Fields{
						"cloud":        cloud,
						"service":      service,
						"datasource":   datasourceName,
						"files_merged": len(readObjectKeys),
					}).Info("Merged files")
				} else {
					logrus.WithFields(logrus.Fields{
						"cloud":        cloud,
						"service":      service,
						"datasource":   datasourceName,
						"files_merged": len(readObjectKeys),
					}).Info("No files found to merge")
				}

				// delete the read files from S3
				for _, key := range readObjectKeys {
					_, err := s3Client.DeleteObject(context.TODO(), &s3.DeleteObjectInput{
						Bucket: aws.String(bucket),
						Key:    aws.String(key),
					})
					if err != nil {
						logrus.WithFields(logrus.Fields{
							"cloud":      cloud,
							"service":    service,
							"datasource": datasourceName,
							"bucket":     bucket,
							"key":        key,
							"error":      err,
						}).Error("Failed to delete object from S3")
						continue
					}
				}
			}
		}
	}
	logrus.Info("Done merging files...")
}
