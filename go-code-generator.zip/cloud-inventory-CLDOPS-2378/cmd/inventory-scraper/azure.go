package main

import (
	"context"
	"strings"
	"sync"
	"time"

	"github.com/Azure/go-autorest/autorest/azure/auth"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/catalog"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/processor"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/subscription"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

func InitiateAzureScrape(waitgroup *sync.WaitGroup, storageManager *storage.StorageManager, reportTime time.Time) {
	waitgroup.Add(1)
	azureSummariesChannel := make(chan []meta.AzureResourceSummaryModel, 1000)
	azureProcessor := processor.NewAzureJobProcessor(azureViper.GetInt("processors"), 1000, azureSummariesChannel)
	azureProcessor.Start()

	var azureSummaryWaitGroup sync.WaitGroup
	go func() {
		azureSummaryWaitGroup.Add(1)
		ProcessAzureSummaries(context.TODO(), azureSummariesChannel, &azureSummaryWaitGroup, reportTime, storageManager)
	}()

	authorizer, err := auth.NewAuthorizerFromEnvironment()
	if err != nil {
		panic(err)
	}

	// ingest subscription info once
	azureProcessor.AddJob(processor.NewAzureJob(
		&subscription.Controller,
		context.TODO(),
		"nil",
		reportTime,
		authorizer,
		storageManager,
	))

	subscriptionList := strings.Split(azureViper.GetString("subscriptions"), ",")
	for _, subscriptionId := range subscriptionList {
		for _, serviceController := range catalog.AzureServiceControllers {
			azureProcessor.AddJob(processor.NewAzureJob(
				serviceController,
				context.TODO(),
				subscriptionId,
				reportTime,
				authorizer,
				storageManager,
			))
		}
	}

	go func() {
		azureProcessor.WaitForCompletion()
		close(azureSummariesChannel)
		azureSummaryWaitGroup.Wait()
		waitgroup.Done()
	}()
}

func ProcessAzureSummaries(ctx context.Context, summaryChan chan []meta.AzureResourceSummaryModel, waitGroup *sync.WaitGroup, reportTime time.Time, storageManager *storage.StorageManager) {
	defer waitGroup.Done()
	storageConfig := storage.StorageContextConfig{
		Cloud:      "custom",
		Service:    "meta",
		DataSource: "azure_resource_summary",
		Date:       reportTime,
	}
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(meta.AzureResourceSummaryModel))
	if err != nil {
		return
	}
	defer storageContextSet.Close(ctx)
	for summaries := range summaryChan {
		for _, summary := range summaries {
			errors := storageContextSet.Store(ctx, &summary)
			if errors != nil {
				for datasource, err := range errors {
					logrus.WithFields(logrus.Fields{
						"subscription_id": summary.SubscriptionId,
						"cloud":           "custom",
						"service":         "meta",
						"datasouce":       datasource,
						"error":           err,
					}).Error("Error storing metadata")
				}
			}
		}
	}
	logrus.Info("Done processing Azure summary metadata")
}
