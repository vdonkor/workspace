package main

import (
	"context"
	"os"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/aws/retry"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

var (
	parquetS3Viper = viper.New()
	logViper       = viper.New()
	awsViper       = viper.New()
	azureViper     = viper.New()
	infraviewViper = viper.New()
)

func initLogOptions() {
	logViper.SetEnvPrefix("log")
	logViper.AutomaticEnv()

	logViper.BindEnv("level")
	logViper.SetDefault("level", "info")

	logViper.BindEnv("caller")
	logViper.SetDefault("caller", false)
}

func initParquetS3Options() {
	parquetS3Viper.SetEnvPrefix("parquet_s3")
	parquetS3Viper.AutomaticEnv()

	parquetS3Viper.BindEnv("bucket")

	parquetS3Viper.BindEnv("path_prefix")
	parquetS3Viper.SetDefault("path_prefix", "parquet/")

	parquetS3Viper.BindEnv("file_extension")
	parquetS3Viper.SetDefault("file_extension", "parquet")

	parquetS3Viper.BindEnv("parquet_pages")
	parquetS3Viper.SetDefault("parquet_pages", 4)
}

func initAwsOptions() {
	awsViper.SetEnvPrefix("aws")
	awsViper.AutomaticEnv()

	awsViper.BindEnv("accounts")

	awsViper.BindEnv("regions")
	awsViper.SetDefault("regions", "us-east-1,us-west-2")

	awsViper.BindEnv("assume_role_name")

	awsViper.BindEnv("dynamodb_account_table_name")
	awsViper.SetDefault("dynamodb_account_table_name", "echs-account-inventory")

	awsViper.BindEnv("processors")
	awsViper.SetDefault("processors", 16)
}

func initAzureOptions() {
	azureViper.SetEnvPrefix("azure")
	azureViper.AutomaticEnv()

	azureViper.BindEnv("subscriptions")
	azureViper.SetDefault("subscriptions", "a1a37914-9567-4916-9086-2d55f6b55144,375d353c-307f-4ba7-8ca7-bd5e529e914a,bc77ac74-33f2-4a90-9574-f8ea63c99904,1ad02958-b80f-41eb-8326-f1e05c0b9843,a05e833c-4967-41ae-ba72-4379a9e1a5a9,46aed943-358b-4c78-b1c4-18b33d55a183,4bc3515c-aa84-4136-aef6-4541f496a9ed,651a20c7-1288-40bf-88fd-a1b235cdb8ab")

	azureViper.BindEnv("processors")
	azureViper.SetDefault("processors", 16)
}

func initInfraviewOptions() {
	infraviewViper.SetEnvPrefix("infraview")
	infraviewViper.AutomaticEnv()

	infraviewViper.BindEnv("api_username")

	infraviewViper.BindEnv("api_password")
}

func init() {
	initLogOptions()
	initParquetS3Options()
	initAwsOptions()
	initAzureOptions()
	initInfraviewOptions()
}

func stringInList(s string, sList []string) bool {
	for _, s2 := range sList {
		if s == s2 {
			return true
		}
	}
	return false
}

func main() {
	baseAwsConfig, err := config.LoadDefaultConfig(context.TODO(), config.WithRetryer(func() aws.Retryer {
		var retryer aws.Retryer
		retryer = retry.NewStandard()
		retryer = retry.AddWithMaxAttempts(retryer, 5)
		retryer = retry.AddWithMaxBackoffDelay(retryer, 90)
		return retryer
	}))
	if err != nil {
		panic(err)
	}

	reportTime := time.Now().UTC()
	parquetBackend := storage.NewParquetS3Backend(parquetS3Viper.GetString("bucket"), parquetS3Viper.GetString("path_prefix"), parquetS3Viper.GetString("file_extension"), s3.NewFromConfig(baseAwsConfig), int64(parquetS3Viper.GetInt("parquet_pages")))

	storageManager := storage.StorageManager{
		StorageBackends: []storage.StorageBackend{
			parquetBackend,
		},
	}

	scrapeWaitGroup := sync.WaitGroup{}
	InitiateAwsScrape(&scrapeWaitGroup, &storageManager, reportTime, baseAwsConfig)
	InitiateAzureScrape(&scrapeWaitGroup, &storageManager, reportTime)
	InitiateInfraviewScrape(&scrapeWaitGroup, &storageManager, reportTime)

	scrapeWaitGroup.Wait()

	errors := parquetBackend.CloseStorageContexts(context.TODO())
	if len(errors) != 0 {
		logrus.WithFields(logrus.Fields{"errors": errors}).Error("errors closing parquet storage contexts")
		os.Exit(1)
	} else {
		logrus.Info("Parquet storage contexts closed")
	}
}
