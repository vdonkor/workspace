package main

import (
	"context"
	"fmt"
	"sync"
	"time"

	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/infraview/performancedata"
)

func InitiateInfraviewScrape(waitgroup *sync.WaitGroup, storageManager *storage.StorageManager, reportTime time.Time) {
	waitgroup.Add(1)
	go func() {
		errs := performancedata.Controller.Process(context.TODO(), reportTime, infraviewViper.GetString("api_username"), infraviewViper.GetString("api_password"), storageManager)
		fmt.Println(errs)
		waitgroup.Done()
	}()
}
