package main

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials/stscreds"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/sts"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/catalog"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/processor"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/accountinventory"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
	"gitlab.epa.gov/task7/libraries/go-aws-accounts/accounts"
)

func InitiateAwsScrape(waitgroup *sync.WaitGroup, storageManager *storage.StorageManager, reportTime time.Time, baseAwsConfig aws.Config) {
	waitgroup.Add(1)
	awsSummariesChannel := make(chan []meta.AwsResourceSummaryModel, 1000)
	awsProcessor := processor.NewAwsJobProcessor(awsViper.GetInt("processors"), 1000, awsSummariesChannel)
	awsProcessor.Start()

	var awsSummaryWaitGroup sync.WaitGroup
	go func() {
		awsSummaryWaitGroup.Add(1)
		ProcessAwsSummaries(context.TODO(), awsSummariesChannel, &awsSummaryWaitGroup, reportTime, storageManager)
	}()

	dynamodbClient := dynamodb.NewFromConfig(baseAwsConfig)

	accountsString := awsViper.GetString("accounts")
	var accountList []string
	if accountsString == "dynamodb" {
		accountDetails, err := accounts.GetAccounts(context.TODO(), dynamodbClient, awsViper.GetString("dynamodb_account_table_name"))
		if err != nil {
			panic(err)
		}
		accountList = make([]string, len(accountDetails))
		for i, account := range accountDetails {
			accountList[i] = account.AccountID
		}

		// load account inventory into S3
		storageConfig := storage.StorageContextConfig{
			Cloud:      "custom",
			Service:    "accountinventory",
			DataSource: "accounts",
			Date:       reportTime,
		}

		err = accountinventory.AccountDataSource(context.TODO(), accountDetails, reportTime, storageConfig, storageManager)
		if err != nil {
			panic(err)
		}
	} else {
		accountList = strings.Split(accountsString, ",")
	}

	regions := strings.Split(awsViper.GetString("regions"), ",")
	assumeRoleName := awsViper.GetString("assume_role_name")

	stsSvc := sts.NewFromConfig(baseAwsConfig)

	for _, account := range accountList {
		accountAwsConfig := baseAwsConfig.Copy()
		creds := stscreds.NewAssumeRoleProvider(stsSvc, fmt.Sprintf("arn:aws:iam::%s:role/%s", account, assumeRoleName))
		accountAwsConfig.Credentials = aws.NewCredentialsCache(creds)
		for _, region := range regions {
			regionConfig := accountAwsConfig.Copy()
			regionConfig.Region = region
			for _, serviceController := range catalog.AwsServiceControllers {
				regionOverrides := serviceController.GetRegionOverrides()
				if len(regionOverrides) > 0 && !stringInList(region, regionOverrides) {
					//skip running in this region
					continue
				}

				awsProcessor.AddJob(processor.NewAwsJob(
					serviceController,
					context.TODO(),
					account,
					region,
					reportTime,
					regionConfig,
					storageManager,
				))
			}
		}
	}

	go func() {
		awsProcessor.WaitForCompletion()
		close(awsSummariesChannel)
		awsSummaryWaitGroup.Wait()
		waitgroup.Done()
	}()
}

func ProcessAwsSummaries(ctx context.Context, summaryChan chan []meta.AwsResourceSummaryModel, waitGroup *sync.WaitGroup, reportTime time.Time, storageManager *storage.StorageManager) {
	defer waitGroup.Done()
	storageConfig := storage.StorageContextConfig{
		Cloud:      "custom",
		Service:    "meta",
		DataSource: "aws_resource_summary",
		Date:       reportTime,
	}
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(meta.AwsResourceSummaryModel))
	if err != nil {
		return
	}
	defer storageContextSet.Close(ctx)
	for summaries := range summaryChan {
		for _, summary := range summaries {
			errors := storageContextSet.Store(ctx, &summary)
			if errors != nil {
				for datasource, err := range errors {
					logrus.WithFields(logrus.Fields{
						"account_id": summary.AccountId,
						"region":     summary.Region,
						"cloud":      "custom",
						"service":    "meta",
						"datasouce":  datasource,
						"error":      err,
					}).Error("Error storing metadata")
				}
			}
		}
	}
	logrus.Info("Done processing AWS summary metadata")
}
