package main

import (
	"context"
	"fmt"
	"os"

	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/athena"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/catalog"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/codegen"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/processor"
)

func main() {
	cfg, err := config.LoadDefaultConfig(context.TODO(), config.WithRegion("us-east-1"))
	if err != nil {
		panic(err)
	}
	athenaClient := athena.NewFromConfig(cfg)

	viewProcessor := processor.NewViewJobProcessor(5, 1000)
	viewProcessor.Start()

	errorChan := make(chan error)
	numErrors := 0
	go func() {
		for err := range errorChan {
			numErrors++
			fmt.Println(err)
		}
	}()

	for cloud, serviceMapping := range catalog.DatasourceModels {
		viewDirectory := fmt.Sprintf("./view_queries/%s/", cloud)

		if _, err := os.Stat(viewDirectory); os.IsNotExist(err) {
			err := os.Mkdir(viewDirectory, 0755)
			if err != nil {
				panic(err)
			}
		}

		for service, datasourceMapping := range serviceMapping {
			serviceDirectory := fmt.Sprintf("%s%s/", viewDirectory, service)
			if _, err := os.Stat(serviceDirectory); os.IsNotExist(err) {
				err := os.Mkdir(serviceDirectory, 0755)
				if err != nil {
					panic(err)
				}
			}
			for datasource, model := range datasourceMapping {
				// get the primary key of the model

				views, err := codegen.GetModelViews(cloud, service, datasource, model)
				if err != nil {
					panic(err)
				}

				for _, view := range views {
					err := os.WriteFile(serviceDirectory+view.Filename, []byte(view.View), 0644)
					if err != nil {
						panic(err)
					}

					viewProcessor.AddJob(processor.NewViewJob(context.TODO(), view.Name, view.View, "AwsGlueCatalog", "cloud-inventory", "cloud-inventory", athenaClient, errorChan))
				}
			}
		}
	}

	files, err := os.ReadDir("./custom_views/")
	if err != nil {
		panic(err)
	}

	for _, file := range files {
		if file.IsDir() {
			continue
		}
		fileData, err := os.ReadFile("./custom_views/" + file.Name())
		if err != nil {
			panic(err)
		}
		viewProcessor.AddJob(processor.NewViewJob(context.TODO(), file.Name(), string(fileData), "AwsGlueCatalog", "cloud-inventory", "cloud-inventory", athenaClient, errorChan))

	}

	viewProcessor.WaitForCompletion()
	close(errorChan)

	if numErrors > 0 {
		panic("Errors creating views")
	}
}
