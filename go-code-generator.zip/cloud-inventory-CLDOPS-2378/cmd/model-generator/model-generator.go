package main

import (
	"errors"
	"flag"
	"fmt"
	"go/types"
	"os"

	"github.com/hashicorp/hcl/v2/hclsimple"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/codegen"
	"golang.org/x/tools/go/packages"
)

var (
	configFileName = flag.String("f", "", "the configuration filename")
	baseOutputPath = flag.String("o", "", "")
)

var awsPrimaryFields []*codegen.ParquetModelField = []*codegen.ParquetModelField{
	{
		Name: "AccountId",
		Type: "string",
	},
	{
		Name: "Region",
		Type: "string",
	},
	{
		Name:        "ReportTime",
		Type:        "int64",
		IsTimeField: true,
	},
}

var azurePrimaryFields []*codegen.ParquetModelField = []*codegen.ParquetModelField{
	{
		Name:        "ReportTime",
		Type:        "int64",
		IsTimeField: true,
	},
}

func makeDir(path string) {
	if _, err := os.Stat(path); os.IsNotExist(err) {
		err := os.Mkdir(path, 0755)
		if err != nil {
			panic(err)
		}
	}
}

type FileConfiguration struct {
	AwsServiceConfigurations   []AwsServiceConfiguration   `hcl:"aws_service,block"`
	AzureServiceConfigurations []AzureServiceConfiguration `hcl:"azure_service,block"`
}

type AwsServiceConfiguration struct {
	Service     string          `hcl:"service,label"`
	LibraryPath string          `hcl:"library_path"`
	DataSources []AwsDataSource `hcl:"datasource,block"`
}

type AwsDataSource struct {
	DataSource         string                 `hcl:"datasource,label"`
	PrimaryObjectName  string                 `hcl:"primary_object_name"`
	PrimaryObjectField string                 `hcl:"primary_object_field"`
	ApiFunction        string                 `hcl:"api_function"`
	PrimaryObjectPath  []string               `hcl:"primary_object_path"`
	Paginate           bool                   `hcl:"paginate"`
	Children           []DataSourceChild      `hcl:"child,block"`
	ExtraFields        []DataSourceExtraField `hcl:"extra_field,block"`
	ModelsOnly         bool                   `hcl:"models_only"`
	ExcludedFields     []string               `hcl:"excluded_fields,optional"`
	FieldConversions   []FieldConversion      `hcl:"field_conversion,block"`
}

type AzureServiceConfiguration struct {
	Service     string            `hcl:"service,label"`
	LibraryPath string            `hcl:"library_path"`
	DataSources []AzureDataSource `hcl:"datasource,block"`
}

type AzureDataSource struct {
	DataSource            string                 `hcl:"datasource,label"`
	ClientName            string                 `hcl:"client_name"`
	PrimaryObjectName     string                 `hcl:"primary_object_name"`
	PrimaryObjectField    string                 `hcl:"primary_object_field"`
	ApiFunction           string                 `hcl:"api_function"`
	ApiFunctionParameters string                 `hcl:"api_function_parameters"`
	Children              []DataSourceChild      `hcl:"child,block"`
	ExtraFields           []DataSourceExtraField `hcl:"extra_field,block"`
	ExcludedFields        []string               `hcl:"excluded_fields,optional"`
	FieldConversions      []FieldConversion      `hcl:"field_conversion,block"`
	HasResourceID         bool                   `hcl:"has_resource_id"`
	ExcludeSubscriptionId bool                   `hcl:"exclude_subscription_id,optional"`
	ModelsOnly            bool                   `hcl:"models_only,optional"`
}

type DataSourceChild struct {
	ResourceName   string                 `hcl:"resource_name"`
	ResourceField  string                 `hcl:"resource_field"`
	ResourceType   string                 `hcl:"resource_type"`
	ExcludedFields []string               `hcl:"excluded_fields,optional"`
	ExtraFields    []DataSourceExtraField `hcl:"extra_field,block"`
	Children       []DataSourceChild      `hcl:"child,block"`
}

type DataSourceExtraField struct {
	Name string `hcl:"name"`
	Type string `hcl:"type"`
}

type FieldConversion struct {
	SourceFieldName         string  `hcl:"source_field_name"`
	SourceFieldNameOverride *string `hcl:"source_field_name_override,optional"`
	TargetFieldName         string  `hcl:"target_field_name"`
	TargetFieldType         string  `hcl:"target_field_type"`
	ConversionFunctionName  string  `hcl:"conversion_function_name"`
}

func populateChild(parentModel *codegen.ParquetModelStruct, child DataSourceChild, apiPackages []*packages.Package, primaryObjectName string) []*codegen.ParquetModelStruct {
	var foundObject types.Object
	for _, pkg := range apiPackages {
		foundObject = pkg.Types.Scope().Lookup(child.ResourceName)
		if foundObject != nil {
			break
		}
	}
	if foundObject == nil {
		panic("Could not find object " + child.ResourceName + " in any of the loaded packages")
	}

	//object is a types.Object == types.TypeName, i.e. "type DescribeInstancesOutput struct {}..."
	childObject := foundObject.(*types.TypeName).Type().(*types.Named)

	moddedExcludedFields := append(child.ExcludedFields, "Response")
	childModel, err := codegen.NewParquetModelStruct(childObject, primaryObjectName, moddedExcludedFields, nil)
	if err != nil {
		panic(err)
	}

	for _, extraField := range child.ExtraFields {
		childModel.Fields = append(childModel.Fields, &codegen.ParquetModelField{
			Name: extraField.Name,
			Type: extraField.Type,
		})
	}

	var childType string
	switch child.ResourceType {
	case "literal":
		childType = "*" + childModel.Name
	case "list":
		childType = "[]*" + childModel.Name
	}

	parentModel.Fields = append(parentModel.Fields, &codegen.ParquetModelField{
		Name: child.ResourceField,
		Type: childType,
	})
	models := []*codegen.ParquetModelStruct{childModel}
	models = append(models, childModel.GetChildModels()...)

	for _, grandChild := range child.Children {
		grandChildModels := populateChild(childModel, grandChild, apiPackages, primaryObjectName)
		models = append(models, grandChildModels...)
	}

	return models
}

func processAzureServiceConfiguration(serviceConfig AzureServiceConfiguration) error {
	var servicePackages []*packages.Package

	servicePackagePath := serviceConfig.LibraryPath
	autorestDatePackagePath := "github.com/Azure/go-autorest/autorest/date"

	pkgs, err := packages.Load(&packages.Config{
		Mode: packages.NeedName | packages.NeedFiles | packages.NeedSyntax | packages.NeedTypes | packages.NeedImports | packages.NeedDeps,
	}, servicePackagePath, autorestDatePackagePath)
	if err != nil {
		panic(err)
	}
	packageMap := map[string]*packages.Package{}

	for _, pkg := range pkgs {
		pkgPath := pkg.PkgPath
		packageMap[pkgPath] = pkg
	}
	servicePackages = pkgs

	for _, datasourceConfig := range serviceConfig.DataSources {
		var foundObject types.Object
		for _, pkg := range servicePackages {
			foundObject = pkg.Types.Scope().Lookup(datasourceConfig.PrimaryObjectName)
			if foundObject != nil {
				break
			}
		}
		if foundObject == nil {
			return errors.New("Could not find object " + datasourceConfig.PrimaryObjectName + " in any of the loaded packages")
		}

		//object is a types.Object == types.TypeName, i.e. "type DescribeInstancesOutput struct {}..."
		object := foundObject.(*types.TypeName).Type().(*types.Named)

		fieldConversions := []*codegen.ParquetModelFieldConversion{}
		for _, conversion := range datasourceConfig.FieldConversions {
			fieldConversions = append(fieldConversions, &codegen.ParquetModelFieldConversion{
				SourceFieldName:         conversion.SourceFieldName,
				SourceFieldNameOverride: conversion.SourceFieldNameOverride,
				ConversionFunctionName:  conversion.ConversionFunctionName,
				TargetField: codegen.ParquetModelField{
					Name: conversion.TargetFieldName,
					Type: conversion.TargetFieldType,
				},
			})
		}
		moddedExcludedFields := append(datasourceConfig.ExcludedFields, "Response")
		primaryModel, err := codegen.NewParquetModelStruct(object, datasourceConfig.PrimaryObjectName, moddedExcludedFields, fieldConversions)
		if err != nil {
			panic(err)
		}

		models := []*codegen.ParquetModelStruct{primaryModel}
		models = append(models, primaryModel.GetChildModels()...)

		primaryModel.Fields = append(primaryModel.Fields, azurePrimaryFields...)
		if !datasourceConfig.ExcludeSubscriptionId {
			primaryModel.Fields = append(primaryModel.Fields, &codegen.ParquetModelField{
				Name:        "SubscriptionId",
				Type:        "string",
				IsTimeField: false,
			})
		}
		if datasourceConfig.HasResourceID {
			primaryModel.Fields = append(primaryModel.Fields, &codegen.ParquetModelField{
				Name:        "ResourceGroup",
				Type:        "string",
				IsTimeField: false,
			})
		}

		for _, extraField := range datasourceConfig.ExtraFields {
			primaryModel.Fields = append(primaryModel.Fields, &codegen.ParquetModelField{
				Name: extraField.Name,
				Type: extraField.Type,
			})
		}

		for _, child := range datasourceConfig.Children {
			childModels := populateChild(primaryModel, child, servicePackages, datasourceConfig.PrimaryObjectName)
			models = append(models, childModels...)
		}

		models = codegen.DeduplicateModels(models)

		for _, model := range models {
			model.PopulateFieldTags(datasourceConfig.PrimaryObjectField)
		}

		datasourceFile := codegen.AzureDataSourceFile{
			ServiceName:           serviceConfig.Service,
			DataSourceName:        datasourceConfig.DataSource,
			ClientName:            datasourceConfig.ClientName,
			PrimaryObjectName:     datasourceConfig.PrimaryObjectName,
			ApiFunction:           datasourceConfig.ApiFunction,
			ApiFunctionParameters: datasourceConfig.ApiFunctionParameters,
			Models:                models,
			PrimaryModel:          primaryModel,
			HasResourceID:         datasourceConfig.HasResourceID,
			ExcludeSubscriptionId: datasourceConfig.ExcludeSubscriptionId,
			ModelsOnly:            datasourceConfig.ModelsOnly,
			PackageUrl:            serviceConfig.LibraryPath,
		}
		datasourceCode := datasourceFile.SourceCode()

		outputPath := *baseOutputPath
		for _, dir := range []string{"azure", serviceConfig.Service} {
			outputPath += "/" + dir
			makeDir(outputPath)
		}
		outputPath += "/" + datasourceConfig.DataSource + "_model.go"

		outputFile, err := os.Create(outputPath)
		if err != nil {
			panic(err)
		}

		outputFile.WriteString(datasourceCode)

		outputFile.Close()

		fmt.Println("generated file " + outputPath)
	}

	return nil
}

func processAwsServiceConfiguration(serviceConfig AwsServiceConfiguration) error {
	var servicePackages []*packages.Package

	servicePackagePath := serviceConfig.LibraryPath
	serviceTypesPackagePath := serviceConfig.LibraryPath + "/types"

	pkgs, err := packages.Load(&packages.Config{
		Mode: packages.NeedName | packages.NeedFiles | packages.NeedSyntax | packages.NeedTypes | packages.NeedImports | packages.NeedDeps,
	}, servicePackagePath, serviceTypesPackagePath)
	if err != nil {
		panic(err)
	}
	packageMap := map[string]*packages.Package{}

	servicePackages = pkgs
	for _, pkg := range pkgs {
		pkgPath := pkg.PkgPath
		packageMap[pkgPath] = pkg
	}

	for _, datasourceConfig := range serviceConfig.DataSources {
		var foundObject types.Object
		for _, pkg := range servicePackages {
			foundObject = pkg.Types.Scope().Lookup(datasourceConfig.PrimaryObjectName)
			if foundObject != nil {
				break
			}
		}
		if foundObject == nil {
			return errors.New("Could not find object " + datasourceConfig.PrimaryObjectName + " in any of the loaded packages")
		}

		//object is a types.Object == types.TypeName, i.e. "type DescribeInstancesOutput struct {}..."
		object := foundObject.(*types.TypeName).Type().(*types.Named)

		fieldConversions := []*codegen.ParquetModelFieldConversion{}
		for _, conversion := range datasourceConfig.FieldConversions {
			fieldConversions = append(fieldConversions, &codegen.ParquetModelFieldConversion{
				SourceFieldName:         conversion.SourceFieldName,
				SourceFieldNameOverride: conversion.SourceFieldNameOverride,
				ConversionFunctionName:  conversion.ConversionFunctionName,
				TargetField: codegen.ParquetModelField{
					Name: conversion.TargetFieldName,
					Type: conversion.TargetFieldType,
				},
			})
		}
		primaryModel, err := codegen.NewParquetModelStruct(object, datasourceConfig.PrimaryObjectName, datasourceConfig.ExcludedFields, fieldConversions)
		if err != nil {
			panic(err)
		}

		models := []*codegen.ParquetModelStruct{primaryModel}
		models = append(models, primaryModel.GetChildModels()...)

		primaryModel.Fields = append(primaryModel.Fields, awsPrimaryFields...)

		for _, extraField := range datasourceConfig.ExtraFields {
			primaryModel.Fields = append(primaryModel.Fields, &codegen.ParquetModelField{
				Name: extraField.Name,
				Type: extraField.Type,
			})
		}

		for _, child := range datasourceConfig.Children {
			childModels := populateChild(primaryModel, child, servicePackages, datasourceConfig.PrimaryObjectName)
			models = append(models, childModels...)
		}

		models = codegen.DeduplicateModels(models)

		for _, model := range models {
			model.PopulateFieldTags(datasourceConfig.PrimaryObjectField)
		}

		datasourceFile := codegen.AwsDataSourceFile{
			ServiceName:       serviceConfig.Service,
			DataSourceName:    datasourceConfig.DataSource,
			PrimaryObjectName: datasourceConfig.PrimaryObjectName,
			ApiFunction:       datasourceConfig.ApiFunction,
			Models:            models,
			PrimaryModel:      primaryModel,
			PrimaryObjectPath: datasourceConfig.PrimaryObjectPath,
			Paginate:          datasourceConfig.Paginate,
			ModelsOnly:        datasourceConfig.ModelsOnly,
		}
		datasourceCode := datasourceFile.SourceCode()

		outputPath := *baseOutputPath
		for _, dir := range []string{"aws", serviceConfig.Service} {
			outputPath += "/" + dir
			makeDir(outputPath)
		}
		outputPath += "/" + datasourceConfig.DataSource + "_model.go"

		outputFile, err := os.Create(outputPath)
		if err != nil {
			panic(err)
		}

		outputFile.WriteString(datasourceCode)

		outputFile.Close()

		fmt.Println("generated file " + outputPath)
	}

	return nil
}

func main() {
	flag.Parse()

	var config FileConfiguration
	err := hclsimple.DecodeFile(*configFileName, nil, &config)
	if err != nil {
		panic(err)
	}

	for _, serviceConfig := range config.AwsServiceConfigurations {
		processAwsServiceConfiguration(serviceConfig)
	}

	for _, serviceConfig := range config.AzureServiceConfigurations {
		processAzureServiceConfiguration(serviceConfig)
	}

}
