package codegen

//go:generate go run ../../../cmd/model-generator/ -f ../../service-specs/azure/web_spec.hcl -o ../../../pkg

//go:generate go fmt ../../../pkg/azure/web/
