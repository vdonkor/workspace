package codegen

//go:generate go run ../../../cmd/model-generator/ -f ../../service-specs/azure/subscription_spec.hcl -o ../../../pkg

//go:generate go fmt ../../../pkg/azure/subscription/
