package compute

import (
	"context"
	"fmt"
	"time"

	"github.com/Azure/azure-sdk-for-go/profiles/latest/compute/mgmt/compute"
	"github.com/Azure/go-autorest/autorest"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/copier"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

func VirtualMachineScaleSetVMDataSource(ctx context.Context, authorizer autorest.Authorizer, subscriptionId string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(VirtualMachineScaleSetVMModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	client := compute.NewVirtualMachineScaleSetsClient(subscriptionId)
	client.Authorizer = authorizer

	iterator, err := client.ListAllComplete(ctx)
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":         storageConfig.Service,
			"data_source":     storageConfig.DataSource,
			"subscription_id": subscriptionId,
			"cloud":           storageConfig.Cloud,
			"error":           err,
		}).Error("error calling VirtualMachineScaleSets ListAllComplete")
		return numModels, err
	}

	scaleSetClient := compute.NewVirtualMachineScaleSetVMsClient(subscriptionId)
	scaleSetClient.Authorizer = authorizer

	for iterator.NotDone() {
		scaleSet := iterator.Value()
		// list all VMs in scale set
		scaleSetRG := GetResourceGroupFromID(*scaleSet.ID)
		vmIterator, err := scaleSetClient.ListComplete(ctx, scaleSetRG, *scaleSet.Name, "", "", "instanceView")
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":         storageConfig.Service,
				"data_source":     storageConfig.DataSource,
				"subscription_id": subscriptionId,
				"cloud":           storageConfig.Cloud,
				"scale_set":       *scaleSet.Name,
				"error":           err,
			}).Error("error calling VirtualMachineScaleSetVMs ListComplete")
			return numModels, err
		}

		for vmIterator.NotDone() {
			value := vmIterator.Value()
			model := new(VirtualMachineScaleSetVMModel)

			copier.Copy(&model, &value)

			model.VirtualMachineScaleSetID = *scaleSet.ID
			model.SubscriptionId = subscriptionId
			model.ReportTime = reportTime.UTC().UnixMilli()
			model.ResourceGroup = GetResourceGroupFromID(model.ID)

			for _, f := range customVirtualMachineScaleSetVMModelPostprocessingFuncs {
				f(ctx, authorizer, model)
			}

			errors := storageContextSet.Store(ctx, model)
			for storageContext, err := range errors {
				storage.LogContextError(storageContext, fmt.Sprintf("Error storing VirtualMachineScaleSetVMModel: %v", err))
			}
			numModels++

			err = vmIterator.NextWithContext(ctx)
			if err != nil {
				logrus.WithFields(logrus.Fields{
					"service":         storageConfig.Service,
					"data_source":     storageConfig.DataSource,
					"subscription_id": subscriptionId,
					"cloud":           storageConfig.Cloud,
					"error":           err,
				}).Error("error iterating VirtualMachineScaleSetVMs ListComplete")
				return numModels, err
			}
		}

		err = iterator.NextWithContext(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":         storageConfig.Service,
				"data_source":     storageConfig.DataSource,
				"subscription_id": subscriptionId,
				"cloud":           storageConfig.Cloud,
				"error":           err,
			}).Error("error iterating VirtualMachineScaleSets ListAllComplete")
			return numModels, err
		}

	}

	return numModels, nil
}
