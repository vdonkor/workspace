package compute

import (
	"context"
	"strings"

	"github.com/Azure/azure-sdk-for-go/profiles/latest/compute/mgmt/compute"
	"github.com/Azure/go-autorest/autorest"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/copier"
)

func init() {
	registerCustomVirtualMachineModelPostprocessingFunc(PostProcessVirtualMachineModel)
}

func PostProcessVirtualMachineModel(ctx context.Context, authorizer autorest.Authorizer, model *VirtualMachineModel) {
	client := compute.NewVirtualMachinesClient(model.SubscriptionId)
	client.Authorizer = authorizer

	view, err := client.InstanceView(ctx, model.ResourceGroup, model.Name)
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"cloud":           "azure",
			"service":         "compute",
			"datasource":      "virtual_machines",
			"vm_name":         model.Name,
			"subscription_id": model.SubscriptionId,
			"error":           err,
		}).Error("error getting instance view")
		return
	}

	if model.VirtualMachineProperties == nil {
		model.VirtualMachineProperties = new(VirtualMachinePropertiesVirtualMachineModel)
	}

	model.VirtualMachineProperties.InstanceView = new(VirtualMachineInstanceViewVirtualMachineModel)

	copier.Copy(model.VirtualMachineProperties.InstanceView, &view)

	// update state fields
	for _, status := range model.VirtualMachineProperties.InstanceView.Statuses {
		codeSplit := strings.Split(status.Code, "/")
		if len(codeSplit) != 2 {
			logrus.WithFields(logrus.Fields{
				"cloud":           "azure",
				"service":         "compute",
				"datasource":      "virtual_machines",
				"vm_name":         model.Name,
				"subscription_id": model.SubscriptionId,
			}).Error("error - status code has unknown format")
		}
		switch codeSplit[0] {
		case "ProvisioningState":
			model.ProvisioningState = codeSplit[1]
		case "PowerState":
			model.PowerState = codeSplit[1]
		default:
			logrus.WithFields(logrus.Fields{
				"cloud":           "azure",
				"service":         "compute",
				"datasource":      "virtual_machines",
				"vm_name":         model.Name,
				"subscription_id": model.SubscriptionId,
				"status_code":     status.Code,
			}).Info("Unknown status code")
		}
	}
}
