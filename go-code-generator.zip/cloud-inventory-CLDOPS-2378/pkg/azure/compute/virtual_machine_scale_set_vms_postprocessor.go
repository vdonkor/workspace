package compute

import (
	"context"
	"strings"

	"github.com/Azure/go-autorest/autorest"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomVirtualMachineScaleSetVMModelPostprocessingFunc(PostProcessVirtualMachineScaleSetVMModel)
}

func PostProcessVirtualMachineScaleSetVMModel(ctx context.Context, authorizer autorest.Authorizer, model *VirtualMachineScaleSetVMModel) {
	if model.VirtualMachineScaleSetVMProperties == nil {
		return
	}
	if model.VirtualMachineScaleSetVMProperties.InstanceView == nil {
		return
	}

	// update state fields
	for _, status := range model.VirtualMachineScaleSetVMProperties.InstanceView.Statuses {
		codeSplit := strings.Split(status.Code, "/")
		if len(codeSplit) != 2 {
			logrus.WithFields(logrus.Fields{
				"cloud":           "azure",
				"service":         "compute",
				"datasource":      "virtual_machines",
				"vm_name":         model.Name,
				"subscription_id": model.SubscriptionId,
			}).Error("error - status code has unknown format")
		}
		switch codeSplit[0] {
		case "ProvisioningState":
			model.ProvisioningState = codeSplit[1]
		case "PowerState":
			model.PowerState = codeSplit[1]
		default:
			logrus.WithFields(logrus.Fields{
				"cloud":           "azure",
				"service":         "compute",
				"datasource":      "virtual_machines",
				"vm_name":         model.Name,
				"subscription_id": model.SubscriptionId,
				"status_code":     status.Code,
			}).Info("Unknown status code")
		}
	}
}
