package operationalinsights

import (
	"context"
	"strings"
	"time"

	"github.com/Azure/go-autorest/autorest"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = OperationalInsightsController{
		DataSources: map[string]func(ctx context.Context, authorizer autorest.Authorizer, subscriptionId string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type OperationalInsightsController struct {
	DataSources map[string]func(ctx context.Context, authorizer autorest.Authorizer, subscriptionId string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (c *OperationalInsightsController) GetName() string {
	return "operationalinsights"
}

func (c *OperationalInsightsController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, authorizer autorest.Authorizer, subscriptionId string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	c.DataSources[dataSourceName] = dataSourceFunc
}

func (c *OperationalInsightsController) Process(ctx context.Context, subscriptionId string, reportTime time.Time, authorizer autorest.Authorizer, storageManager *storage.StorageManager) ([]meta.AzureResourceSummaryModel, map[string]error) {
	errMap := map[string]error{}
	summaries := []meta.AzureResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range c.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "azure",
			Service:    "operationalinsights",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, authorizer, subscriptionId, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		summary := meta.AzureResourceSummaryModel{
			SubscriptionId: subscriptionId,
			Service:        "operationalinsights",
			Resource:       dataSourceName,
			ReportTime:     reportTime.UTC().UnixMilli(),
			Count:          count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":          "azure",
			"service":        "operationalinsights",
			"subscriptionId": subscriptionId,
			"datasource":     dataSourceName,
			"report_time":    reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}

func GetResourceGroupFromID(id string) string {
	parts := strings.Split(id, "/")
	return parts[4]
}
