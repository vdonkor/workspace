package operationalinsights

import (
	"fmt"
	"time"

	"github.com/Azure/azure-sdk-for-go/services/operationalinsights/mgmt/2020-10-01/operationalinsights"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/copier"
	internalstorage "gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"

	"context"

	"github.com/Azure/go-autorest/autorest"
)

func WorkspaceDataSource(ctx context.Context, authorizer autorest.Authorizer, subscriptionId string, reportTime time.Time, storageConfig internalstorage.StorageContextConfig, storageManager *internalstorage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(WorkspaceModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	client := operationalinsights.NewWorkspacesClient(subscriptionId)
	client.Authorizer = authorizer

	results, err := client.List(ctx)
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":         storageConfig.Service,
			"data_source":     storageConfig.DataSource,
			"subscription_id": subscriptionId,
			"cloud":           storageConfig.Cloud,
			"error":           err,
		}).Error("error calling Servers ListComplete")
		return numModels, err
	}

	for _, value := range *results.Value {

		model := new(WorkspaceModel)

		copier.Copy(&model, &value)

		model.SubscriptionId = subscriptionId
		model.ReportTime = reportTime.UTC().UnixMilli()
		model.ResourceGroup = GetResourceGroupFromID(model.ID)

		for _, f := range customWorkspaceModelPostprocessingFuncs {
			f(ctx, authorizer, model)
		}

		errors := storageContextSet.Store(ctx, model)
		for storageContext, err := range errors {
			internalstorage.LogContextError(storageContext, fmt.Sprintf("Error storing WorkspaceModel: %v", err))
		}
		numModels++

		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":         storageConfig.Service,
				"data_source":     storageConfig.DataSource,
				"subscription_id": subscriptionId,
				"cloud":           storageConfig.Cloud,
				"error":           err,
			}).Error("error iterating Accounts ListComplete")
			return numModels, err
		}
	}

	return numModels, nil
}
