package storage

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/Azure/azure-sdk-for-go/services/preview/monitor/mgmt/2021-07-01-preview/insights"
	"github.com/Azure/go-autorest/autorest"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomAccountModelPostprocessingFunc(PostProcessAccountModel)
}

func PostProcessAccountModel(ctx context.Context, authorizer autorest.Authorizer, model *AccountModel) {
	// TODO maybe switch blob/queue/table services from default to listing them from the API - not sure if they're ever "not default"
	metricsClient := insights.NewMetricsClient(model.SubscriptionId)
	metricsClient.Authorizer = authorizer

	accountMetrics, err := GetLastMetricValues(metricsClient, model.ID, []string{"UsedCapacity"}, "average")
	if err != nil {
		return
	}
	model.StorageBytes = accountMetrics["UsedCapacity"]

	blobMetrics, err := GetLastMetricValues(metricsClient, model.ID+"/blobServices/default", []string{"BlobCapacity", "BlobCount"}, "average")
	if err != nil {
		return
	}
	model.BlobStorageBytes = blobMetrics["BlobCapacity"]
	model.BlobCount = blobMetrics["BlobCount"]

	fileMetrics, err := GetLastMetricValues(metricsClient, model.ID+"/fileServices/default", []string{"FileCapacity", "FileCount"}, "average")
	if err != nil {
		return
	}
	model.FileStorageBytes = fileMetrics["FileCapacity"]
	model.FileCount = fileMetrics["FileCount"]

	queueMetrics, err := GetLastMetricValues(metricsClient, model.ID+"/queueServices/default", []string{"QueueCapacity", "QueueCount", "QueueMessageCount"}, "average")
	if err != nil {
		return
	}
	model.QueueStorageBytes = queueMetrics["QueueCapacity"]
	model.QueueCount = queueMetrics["QueueCount"]
	model.QueueMessageCount = queueMetrics["QueueMessageCount"]

	tableMetrics, err := GetLastMetricValues(metricsClient, model.ID+"/tableServices/default", []string{"TableCapacity", "TableCount", "TableEntityCount"}, "average")
	if err != nil {
		return
	}
	model.TableStorageBytes = tableMetrics["TableCapacity"]
	model.TableCount = tableMetrics["TableCount"]
	model.TableEntityCount = tableMetrics["TableEntityCount"]
}

func GetLastMetricValues(client insights.MetricsClient, resourceID string, metricNames []string, aggregationValue string) (map[string]float64, error) {
	endTime := time.Now().UTC()
	startTime := endTime.Add(time.Duration(-5) * time.Hour)
	timespan := fmt.Sprintf("%s/%s", startTime.Format(time.RFC3339), endTime.Format(time.RFC3339))

	resp, err := client.List(context.TODO(), resourceID, timespan, nil, strings.Join(metricNames, ","), aggregationValue, nil, "", "", insights.ResultTypeData, "")
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"cloud":      "azure",
			"service":    "storage",
			"datasource": "accounts",
			"error":      err,
		}).Error("error getting metric values")
		return nil, err
	}

	latestTimestamps := map[string]time.Time{}

	results := map[string]float64{}
	for _, metricName := range metricNames {
		results[metricName] = 0
	}

	for _, v := range *resp.Value {
		for _, t := range *v.Timeseries {
			for _, mv := range *t.Data {
				if mv.Average == nil {
					continue
				}
				if latestTimestamp, ok := latestTimestamps[*v.Name.Value]; !ok {
					results[*v.Name.Value] = *mv.Average
					latestTimestamps[*v.Name.Value] = mv.TimeStamp.Time
				} else {
					if mv.TimeStamp.Time.After(latestTimestamp) {
						results[*v.Name.Value] = *mv.Average
						latestTimestamps[*v.Name.Value] = mv.TimeStamp.Time
					}
				}

			}
		}
	}

	return results, nil
}
