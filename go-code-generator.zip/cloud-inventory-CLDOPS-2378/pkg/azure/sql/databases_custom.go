package sql

import (
	"fmt"
	"time"

	"github.com/Azure/azure-sdk-for-go/services/preview/sql/mgmt/v5.0/sql"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/copier"
	internalstorage "gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"

	"context"

	"github.com/Azure/go-autorest/autorest"
)

func DatabaseDataSource(ctx context.Context, authorizer autorest.Authorizer, subscriptionId string, reportTime time.Time, storageConfig internalstorage.StorageContextConfig, storageManager *internalstorage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(DatabaseModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	client := sql.NewServersClient(subscriptionId)
	client.Authorizer = authorizer

	iterator, err := client.ListComplete(ctx, "administrators")
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":         storageConfig.Service,
			"data_source":     storageConfig.DataSource,
			"subscription_id": subscriptionId,
			"cloud":           storageConfig.Cloud,
			"error":           err,
		}).Error("error calling Servers ListComplete")
		return numModels, err
	}

	for iterator.NotDone() {
		value := iterator.Value()

		databaseClient := sql.NewDatabasesClient(subscriptionId)
		databaseClient.Authorizer = authorizer

		databasePage, err := databaseClient.ListByServer(ctx, GetResourceGroupFromID(*value.ID), *value.Name, "")
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":         storageConfig.Service,
				"data_source":     storageConfig.DataSource,
				"subscription_id": subscriptionId,
				"cloud":           storageConfig.Cloud,
				"error":           err,
			}).Error("error getting database page")
			return numModels, err
		}

		for databasePage.NotDone() {
			for _, dbValue := range databasePage.Values() {
				model := new(DatabaseModel)

				copier.Copy(&model, &dbValue)

				model.SubscriptionId = subscriptionId
				model.ReportTime = reportTime.UTC().UnixMilli()
				model.ResourceGroup = GetResourceGroupFromID(model.ID)
				model.DatabaseID = *value.ID

				for _, f := range customDatabaseModelPostprocessingFuncs {
					f(ctx, authorizer, model)
				}

				errors := storageContextSet.Store(ctx, model)
				for storageContext, err := range errors {
					internalstorage.LogContextError(storageContext, fmt.Sprintf("Error storing DatabaseModel: %v", err))
				}
				numModels++
			}

			err = databasePage.NextWithContext(ctx)
			if err != nil {
				logrus.WithFields(logrus.Fields{
					"service":         storageConfig.Service,
					"data_source":     storageConfig.DataSource,
					"subscription_id": subscriptionId,
					"cloud":           storageConfig.Cloud,
					"error":           err,
				}).Error("error iterating database page")
				return numModels, err
			}
		}

		err = iterator.NextWithContext(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":         storageConfig.Service,
				"data_source":     storageConfig.DataSource,
				"subscription_id": subscriptionId,
				"cloud":           storageConfig.Cloud,
				"error":           err,
			}).Error("error iterating Servers ListComplete")
			return numModels, err
		}
	}

	return numModels, nil
}
