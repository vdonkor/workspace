package accountinventory

import (
	"context"
	"fmt"
	"time"

	"github.com/jinzhu/copier"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	accounts "gitlab.epa.gov/task7/libraries/go-aws-accounts/accounts"
)

type AccountModel struct {
	AccountID        string `parquet:"name=account_id,type=BYTE_ARRAY,convertedtype=utf8" inventory_primary_key:"true"`
	ApplicationName  string `parquet:"name=application_name,type=BYTE_ARRAY,convertedtype=utf8"`
	Environment      string `parquet:"name=environment,type=BYTE_ARRAY,convertedtype=utf8"`
	CloudID          string `parquet:"name=cloud_id,type=BYTE_ARRAY,convertedtype=utf8"`
	CustomerManaged  bool   `parquet:"name=customer_managed,type=BOOLEAN"`
	DevSecOpsManaged bool   `parquet:"name=devsecops_managed,type=BOOLEAN"`
	NCCManaged       bool   `parquet:"name=ncc_managed,type=BOOLEAN"`
	GitlabProjectUrl string `parquet:"name=gitlab_project_url,type=BYTE_ARRAY,convertedtype=utf8"`
	ManagementModel  string `parquet:"name=management_model, type=BYTE_ARRAY,convertedtype=utf8"`
	ReportTime       int64  `parquet:"name=report_time,type=INT64,convertedtype=TIMESTAMP_MILLIS"`
}

func AccountDataSource(ctx context.Context, accounts []accounts.Account, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) error {
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(AccountModel))
	if err != nil {
		return err
	}
	defer storageContextSet.Close(ctx)

	for _, account := range accounts {
		model := new(AccountModel)
		copier.Copy(&model, &account)

		model.ReportTime = reportTime.UTC().UnixMilli()

		if model.CustomerManaged {
			model.ManagementModel = "customer_managed"
		} else if model.DevSecOpsManaged {
			model.ManagementModel = "devsecops_managed"
		} else if model.NCCManaged {
			model.ManagementModel = "ncc_managed"
		} else {
			model.ManagementModel = "undefined"
		}

		errors := storageContextSet.Store(ctx, model)
		for storageContext, err := range errors {
			storage.LogContextError(storageContext, fmt.Sprintf("Error storing AccountModel: %v", err))

		}
	}

	return nil
}
