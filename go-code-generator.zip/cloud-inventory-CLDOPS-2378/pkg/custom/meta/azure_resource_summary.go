package meta

type AzureResourceSummaryModel struct {
	Service        string `parquet:"name=service,type=BYTE_ARRAY,convertedtype=UTF8"`
	Resource       string `parquet:"name=resource,type=BYTE_ARRAY,convertedtype=UTF8"`
	Count          int    `parquet:"name=count,type=INT32"`
	SubscriptionId string `parquet:"name=subscription_id,type=BYTE_ARRAY,convertedtype=UTF8"`
	ReportTime     int64  `parquet:"name=report_time,type=INT64,convertedtype=TIMESTAMP_MILLIS"`
}
