package emr

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/emr"
	"github.com/aws/aws-sdk-go-v2/service/emr/types"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = EmrController{
		DataSources: map[string]func(ctx context.Context, client *emr.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type EmrController struct {
	DataSources map[string]func(ctx context.Context, client *emr.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (e *EmrController) GetRegionOverrides() []string {
	return []string{}
}

func (e *EmrController) GetName() string {
	return "emr"
}

func (e *EmrController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, client *emr.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	e.DataSources[dataSourceName] = dataSourceFunc
}

func (e *EmrController) Process(ctx context.Context, accountId, region string, reportTime time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error) {
	ecsClient := emr.NewFromConfig(cfg)

	errMap := map[string]error{}
	summaries := []meta.AwsResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range e.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "aws",
			Service:    "emr",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, ecsClient, cfg, accountId, region, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		summary := meta.AwsResourceSummaryModel{
			Region:     region,
			AccountId:  accountId,
			Service:    "emr",
			Resource:   dataSourceName,
			ReportTime: reportTime.UTC().UnixMilli(),
			Count:      count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":       "aws",
			"service":     "emr",
			"region":      region,
			"account_id":  accountId,
			"datasource":  dataSourceName,
			"report_time": reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}

func GetTagMap(tags []types.Tag) map[string]string {
	tagMap := make(map[string]string)
	for _, tag := range tags {
		tagMap[*tag.Key] = *tag.Value
	}
	return tagMap
}
