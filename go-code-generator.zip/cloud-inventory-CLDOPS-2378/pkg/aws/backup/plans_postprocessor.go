package backup

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/backup"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomBackupPlansListMemberModelPostprocessingFunc(PostProcessBackupPlansListMemberModel)
}

func PostProcessBackupPlansListMemberModel(ctx context.Context, client *backup.Client, cfg aws.Config, model *BackupPlansListMemberModel) {
	if model.CreationDate != nil {
		model.CreationDateMilli = model.CreationDate.UTC().UnixMilli()
	}
	if model.DeletionDate != nil {
		model.DeletionDateMilli = model.DeletionDate.UTC().UnixMilli()
	}
	if model.LastExecutionDate != nil {
		model.LastExecutionDateMilli = model.LastExecutionDate.UTC().UnixMilli()
	}

	// tags
	tagsOutput, err := client.ListTags(ctx, &backup.ListTagsInput{
		ResourceArn: aws.String(model.BackupPlanArn),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "backup",
			"data_source": "plans",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListTags")
		return
	}
	model.Tags = tagsOutput.Tags

	selectionsOutput, err := client.ListBackupSelections(ctx, &backup.ListBackupSelectionsInput{
		BackupPlanId: aws.String(model.BackupPlanId),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "backup",
			"data_source": "plans",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListBackupSelections")
		return
	}

	model.Selections = []*BackupSelectionsListMemberBackupPlansListMemberModel{}
	for _, selection := range selectionsOutput.BackupSelectionsList {
		selectionModel := new(BackupSelectionsListMemberBackupPlansListMemberModel)
		copier.Copy(&selectionModel, selection)

		if selectionModel.CreationDate != nil {
			selectionModel.CreationDateMilli = selectionModel.CreationDate.UTC().UnixMilli()
		}

		model.Selections = append(model.Selections, selectionModel)
	}
}
