package backup

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/backup"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = BackupController{
		DataSources: map[string]func(ctx context.Context, client *backup.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type BackupController struct {
	DataSources map[string]func(ctx context.Context, client *backup.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (e *BackupController) GetRegionOverrides() []string {
	return []string{}
}

func (e *BackupController) GetName() string {
	return "backup"
}

func (e *BackupController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, client *backup.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	e.DataSources[dataSourceName] = dataSourceFunc
}

func (e *BackupController) Process(ctx context.Context, accountId, region string, reportTime time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error) {
	backupClient := backup.NewFromConfig(cfg)

	errMap := map[string]error{}
	summaries := []meta.AwsResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range e.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "aws",
			Service:    "backup",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, backupClient, cfg, accountId, region, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		summary := meta.AwsResourceSummaryModel{
			Region:     region,
			AccountId:  accountId,
			Service:    "backup",
			Resource:   dataSourceName,
			ReportTime: reportTime.UTC().UnixMilli(),
			Count:      count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":       "aws",
			"service":     "backup",
			"region":      region,
			"account_id":  accountId,
			"datasource":  dataSourceName,
			"report_time": reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}
