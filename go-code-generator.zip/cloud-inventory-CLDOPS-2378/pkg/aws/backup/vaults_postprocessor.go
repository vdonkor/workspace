package backup

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/backup"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomBackupVaultListMemberModelPostprocessingFunc(PostProcessBackupVaultListMemberModel)
}

func PostProcessBackupVaultListMemberModel(ctx context.Context, client *backup.Client, cfg aws.Config, model *BackupVaultListMemberModel) {
	if model.CreationDate != nil {
		model.CreationDateMilli = model.CreationDate.UTC().UnixMilli()
	}
	if model.LockDate != nil {
		model.LockDateMilli = model.LockDate.UTC().UnixMilli()
	}

	// tags
	tagsOutput, err := client.ListTags(ctx, &backup.ListTagsInput{
		ResourceArn: aws.String(model.BackupVaultArn),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "backup",
			"data_source": "plans",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListTags")
		return
	}
	model.Tags = tagsOutput.Tags
}
