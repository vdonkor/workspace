package rds

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/rds"
)

func init() {
	registerCustomDBInstanceModelPostprocessingFunc(PostProcessDBInstanceModel)
}

func PostProcessDBInstanceModel(ctx context.Context, client *rds.Client, cfg aws.Config, model *DBInstanceModel) {
	if model.AutomaticRestartTime != nil {
		model.AutomaticRestartTimeMilli = model.AutomaticRestartTime.UTC().UnixMilli()
	}

	if model.InstanceCreateTime != nil {
		model.InstanceCreateTimeMilli = model.InstanceCreateTime.UTC().UnixMilli()
	}

	if model.LatestRestorableTime != nil {
		model.LatestRestorableTimeMilli = model.LatestRestorableTime.UTC().UnixMilli()
	}
}
