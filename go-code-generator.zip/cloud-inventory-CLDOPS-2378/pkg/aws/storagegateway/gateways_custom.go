package storagegateway

import (
	"context"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/storagegateway"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

func DescribeGatewayInformationOutputDataSource(ctx context.Context, client *storagegateway.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(DescribeGatewayInformationOutputModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	paginator := storagegateway.NewListGatewaysPaginator(client, &storagegateway.ListGatewaysInput{})

	for paginator.HasMorePages() {
		output, err := paginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     storageConfig.Service,
				"data_source": storageConfig.DataSource,
				"account_id":  accountId,
				"region":      region,
				"cloud":       storageConfig.Cloud,
				"error":       err,
			}).Error("error calling ListGateways")
			return numModels, err
		}

		for _, gatewayInfo := range output.Gateways {

			result, err := client.DescribeGatewayInformation(ctx, &storagegateway.DescribeGatewayInformationInput{
				GatewayARN: gatewayInfo.GatewayARN,
			})
			if err != nil {
				logrus.WithFields(logrus.Fields{
					"service":     storageConfig.Service,
					"data_source": storageConfig.DataSource,
					"account_id":  accountId,
					"region":      region,
					"cloud":       storageConfig.Cloud,
					"error":       err,
				}).Error("error calling DescribeGatewayInformation")
				continue
			}

			model := new(DescribeGatewayInformationOutputModel)
			copier.Copy(&model, &result)

			model.AccountId = accountId
			model.Region = region
			model.ReportTime = reportTime.UTC().UnixMilli()

			model.Tags = GetTagMap(result.Tags)

			for _, f := range customDescribeGatewayInformationOutputModelPostprocessingFuncs {
				f(ctx, client, cfg, model)
			}

			errors := storageContextSet.Store(ctx, model)
			for storageContext, err := range errors {
				storage.LogContextError(storageContext, fmt.Sprintf("Error storing DescribeGatewayInformationOutputModel: %v", err))
			}
			numModels++
		}

	}

	return numModels, nil
}
