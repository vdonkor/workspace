package ec2

import (
	"context"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

func ImageDataSource(ctx context.Context, client *ec2.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(ImageModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	result, err := client.DescribeImages(ctx, &ec2.DescribeImagesInput{
		Owners: []string{"self"},
	})

	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     storageConfig.Service,
			"data_source": storageConfig.DataSource,
			"account_id":  accountId,
			"region":      region,
			"cloud":       storageConfig.Cloud,
			"error":       err,
		}).Error("error calling DescribeImages")
		return numModels, err
	}

	for _, image := range result.Images {

		model := new(ImageModel)
		copier.Copy(&model, &image)

		model.Tags = GetTagMap(image.Tags)
		model.AccountId = accountId
		model.Region = region
		model.ReportTime = reportTime.UTC().UnixMilli()

		for _, f := range customImageModelPostprocessingFuncs {
			f(ctx, client, cfg, model)
		}

		errors := storageContextSet.Store(ctx, model)
		for storageContext, err := range errors {
			storage.LogContextError(storageContext, fmt.Sprintf("Error storing ImageModel: %v", err))
		}
		numModels++
	}

	return numModels, nil
}
