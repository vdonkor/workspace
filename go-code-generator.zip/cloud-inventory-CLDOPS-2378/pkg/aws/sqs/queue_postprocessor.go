package sqs

import (
	"context"
	"strconv"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/aws/aws-sdk-go-v2/service/sqs/types"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomQueueModelPostprocessingFunc(PostProcessQueueModel)
}

func PostProcessQueueModel(ctx context.Context, client *sqs.Client, cfg aws.Config, model *QueueModel) {
	attributeResult, err := client.GetQueueAttributes(ctx, &sqs.GetQueueAttributesInput{
		QueueUrl: aws.String(model.QueueUrl),
		AttributeNames: []types.QueueAttributeName{
			types.QueueAttributeNameAll,
		},
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "sqs",
			"data_source": "queues",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling GetQueueAttributes")
		return
	}

	for key, value := range attributeResult.Attributes {
		err = nil
		switch key {
		case "Policy":
			model.Policy = value
		case "VisibilityTimeout":
			model.VisibilityTimeout, err = strconv.ParseInt(value, 10, 64)
		case "MaximumMessageSize":
			model.MaximumMessageSize, err = strconv.ParseInt(value, 10, 64)
		case "MessageRetentionPeriod":
			model.MessageRetentionPeriod, err = strconv.ParseInt(value, 10, 64)
		case "ApproximateNumberOfMessages":
			model.ApproximateNumberOfMessages, err = strconv.ParseInt(value, 10, 64)
		case "ApproximateNumberOfMessagesNotVisible":
			model.ApproximateNumberOfMessagesNotVisible, err = strconv.ParseInt(value, 10, 64)
		case "CreatedTimestamp":
			model.CreatedTimestamp = value
		case "LastModifiedTimestamp":
			model.LastModifiedTimestamp = value
		case "QueueArn":
			model.QueueArn = value
		case "ApproximateNumberOfMessagesDelayed":
			model.ApproximateNumberOfMessagesDelayed, err = strconv.ParseInt(value, 10, 64)
		case "DelaySeconds":
			model.DelaySeconds, err = strconv.ParseInt(value, 10, 64)
		case "ReceiveMessageWaitTimeSeconds":
			model.ReceiveMessageWaitTimeSeconds, err = strconv.ParseInt(value, 10, 64)
		case "RedrivePolicy":
			model.RedrivePolicy = value
		case "FifoQueue":
			if value == "true" {
				model.FifoQueue = true
			}
		case "ContentBasedDeduplication":
			if value == "true" {
				model.ContentBasedDeduplication = true
			}
		case "KmsMasterKeyId":
			model.KmsMasterKeyId = value
		case "KmsDataKeyReusePeriodSeconds":
			model.KmsDataKeyReusePeriodSeconds, err = strconv.ParseInt(value, 10, 64)
		case "DeduplicationScope":
			model.DeduplicationScope = value
		case "FifoThroughputLimit":
			model.FifoThroughputLimit = value
		}
		if err != nil {
			continue
		}
	}

	tagsResult, err := client.ListQueueTags(ctx, &sqs.ListQueueTagsInput{
		QueueUrl: aws.String(model.QueueUrl),
	})
	if err != nil {
		return
	}
	model.Tags = tagsResult.Tags
}
