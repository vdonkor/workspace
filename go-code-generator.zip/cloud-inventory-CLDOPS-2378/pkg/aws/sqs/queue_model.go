package sqs

import (
	"fmt"
	"time"

	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"

	"context"
	"sync"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
)

var customQueueModelPostprocessingFuncs []func(ctx context.Context, client *sqs.Client, cfg aws.Config, x *QueueModel) = []func(ctx context.Context, client *sqs.Client, cfg aws.Config, x *QueueModel){}
var customQueueModelFuncsLock sync.Mutex

func registerCustomQueueModelPostprocessingFunc(f func(ctx context.Context, client *sqs.Client, cfg aws.Config, x *QueueModel)) {
	customQueueModelFuncsLock.Lock()
	defer customQueueModelFuncsLock.Unlock()

	customQueueModelPostprocessingFuncs = append(customQueueModelPostprocessingFuncs, f)
}

func init() {
	Controller.RegisterDataSource("queues", QueueDataSource)
}

type QueueModel struct {
	QueueUrl                              string            `parquet:"name=queue_url,type=BYTE_ARRAY,convertedtype=UTF8" inventory_primary_key:"true"`
	Policy                                string            `parquet:"name=policy,type=BYTE_ARRAY,convertedtype=UTF8"`
	VisibilityTimeout                     int64             `parquet:"name=visibility_timeout,type=INT64"`
	MaximumMessageSize                    int64             `parquet:"name=maximum_message_size,type=INT64"`
	MessageRetentionPeriod                int64             `parquet:"name=message_retention_period,type=INT64"`
	ApproximateNumberOfMessages           int64             `parquet:"name=approximate_number_of_messages,type=INT64"`
	ApproximateNumberOfMessagesNotVisible int64             `parquet:"name=approximate_number_of_messages_not_visible,type=INT64"`
	CreatedTimestamp                      string            `parquet:"name=created_timestamp,type=BYTE_ARRAY,convertedtype=UTF8"`
	LastModifiedTimestamp                 string            `parquet:"name=last_modified_timestamp,type=BYTE_ARRAY,convertedtype=UTF8"`
	QueueArn                              string            `parquet:"name=queue_arn,type=BYTE_ARRAY,convertedtype=UTF8"`
	ApproximateNumberOfMessagesDelayed    int64             `parquet:"name=approximate_number_of_messages_delayed,type=INT64"`
	DelaySeconds                          int64             `parquet:"name=delay_seconds,type=INT64"`
	ReceiveMessageWaitTimeSeconds         int64             `parquet:"name=receive_message_wait_time_seconds,type=INT64"`
	RedrivePolicy                         string            `parquet:"name=redrive_policy,type=BYTE_ARRAY,convertedtype=UTF8"`
	FifoQueue                             bool              `parquet:"name=fifo_queue,type=BOOLEAN"`
	ContentBasedDeduplication             bool              `parquet:"name=content_based_deduplication,type=BOOLEAN"`
	KmsMasterKeyId                        string            `parquet:"name=kms_master_key_id,type=BYTE_ARRAY,convertedtype=UTF8"`
	KmsDataKeyReusePeriodSeconds          int64             `parquet:"name=kms_data_key_reuse_period_seconds,type=INT64"`
	DeduplicationScope                    string            `parquet:"name=deduplication_scope,type=BYTE_ARRAY,convertedtype=UTF8"`
	FifoThroughputLimit                   string            `parquet:"name=fifo_throughput_limit,type=BYTE_ARRAY,convertedtype=UTF8"`
	AccountId                             string            `parquet:"name=account_id,type=BYTE_ARRAY,convertedtype=UTF8"`
	Region                                string            `parquet:"name=region,type=BYTE_ARRAY,convertedtype=UTF8"`
	ReportTime                            int64             `parquet:"name=report_time,type=INT64,convertedtype=TIMESTAMP_MILLIS"`
	Tags                                  map[string]string `parquet:"name=tags,type=MAP,keytype=BYTE_ARRAY,valuetype=BYTE_ARRAY,keyconvertedtype=UTF8,valueconvertedtype=UTF8"`
}

func QueueDataSource(ctx context.Context, client *sqs.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(QueueModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	paginator := sqs.NewListQueuesPaginator(client, &sqs.ListQueuesInput{})

	for paginator.HasMorePages() {
		output, err := paginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     storageConfig.Service,
				"data_source": storageConfig.DataSource,
				"account_id":  accountId,
				"region":      region,
				"cloud":       storageConfig.Cloud,
				"error":       err,
			}).Error("error calling ListQueues")
			return numModels, err
		}

		for _, queueUrl := range output.QueueUrls {

			model := &QueueModel{
				QueueUrl:   queueUrl,
				AccountId:  accountId,
				Region:     region,
				ReportTime: reportTime.UTC().UnixMilli(),
			}

			for _, f := range customQueueModelPostprocessingFuncs {
				f(ctx, client, cfg, model)
			}

			errors := storageContextSet.Store(ctx, model)
			for storageContext, err := range errors {
				storage.LogContextError(storageContext, fmt.Sprintf("Error storing QueueModel: %v", err))
			}
			numModels++
		}

	}

	return numModels, nil
}
