package lambda

// import (
// 	"context"

// 	"github.com/aws/aws-sdk-go-v2/aws"
// 	"github.com/aws/aws-sdk-go-v2/service/lambda"
// 	"github.com/sirupsen/logrus"
// )

// func init() {
// 	registerCustomFunctionConfigurationModelPostprocessingFunc(PostProcessFunctionConfigurationModel)
// }

// func PostProcessFunctionConfigurationModel(ctx context.Context, client *lambda.Client, cfg aws.Config, model *FunctionConfigurationModel) {
// 	result, err := client.ListTags(ctx, &lambda.ListTagsInput{
// 		Resource: aws.String(model.FunctionArn),
// 	})
// 	if err != nil {
// 		logrus.WithFields(logrus.Fields{
// 			"service":     "lambda",
// 			"data_source": "functions",
// 			"account_id":  model.AccountId,
// 			"region":      model.Region,
// 			"cloud":       "aws",
// 			"error":       err,
// 		}).Error("error calling ListTags")
// 		return
// 	}

// 	model.Tags = result.Tags
// }
