package lambda

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/lambda"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = LambdaController{
		DataSources: map[string]func(ctx context.Context, client *lambda.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type LambdaController struct {
	DataSources map[string]func(ctx context.Context, client *lambda.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (e *LambdaController) GetRegionOverrides() []string {
	return []string{}
}

func (e *LambdaController) GetName() string {
	return "lambda"
}

func (e *LambdaController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, client *lambda.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	e.DataSources[dataSourceName] = dataSourceFunc
}

func (e *LambdaController) Process(ctx context.Context, accountId, region string, reportTime time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error) {
	lambdaClient := lambda.NewFromConfig(cfg)

	errMap := map[string]error{}
	summaries := []meta.AwsResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range e.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "aws",
			Service:    "lambda",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, lambdaClient, cfg, accountId, region, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		summary := meta.AwsResourceSummaryModel{
			Region:     region,
			AccountId:  accountId,
			Service:    "lambda",
			Resource:   dataSourceName,
			ReportTime: reportTime.UTC().UnixMilli(),
			Count:      count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":       "aws",
			"service":     "lambda",
			"region":      region,
			"account_id":  accountId,
			"datasource":  dataSourceName,
			"report_time": reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}
