package dynamodb

import (
	"context"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

func TableDescriptionDataSource(ctx context.Context, client *dynamodb.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(TableDescriptionModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	paginator := dynamodb.NewListTablesPaginator(client, &dynamodb.ListTablesInput{})

	for paginator.HasMorePages() {
		output, err := paginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     storageConfig.Service,
				"data_source": storageConfig.DataSource,
				"account_id":  accountId,
				"region":      region,
				"cloud":       storageConfig.Cloud,
				"error":       err,
			}).Error("error calling ListTables")
			return numModels, err
		}

		for _, tableName := range output.TableNames {
			result, err := client.DescribeTable(ctx, &dynamodb.DescribeTableInput{
				TableName: aws.String(tableName),
			})
			if err != nil {
				logrus.WithFields(logrus.Fields{
					"service":     storageConfig.Service,
					"data_source": storageConfig.DataSource,
					"account_id":  accountId,
					"region":      region,
					"cloud":       storageConfig.Cloud,
					"table_name":  tableName,
					"error":       err,
				}).Error("error calling DescribeTable")
				continue
			}

			tagsResult, err := client.ListTagsOfResource(ctx, &dynamodb.ListTagsOfResourceInput{
				ResourceArn: result.Table.TableArn,
			})
			if err != nil {
				logrus.WithFields(logrus.Fields{
					"service":     storageConfig.Service,
					"data_source": storageConfig.DataSource,
					"account_id":  accountId,
					"region":      region,
					"cloud":       storageConfig.Cloud,
					"table_name":  tableName,
					"error":       err,
				}).Error("error calling ListTagsOfResource")
				continue
			}

			model := new(TableDescriptionModel)
			copier.Copy(&model, result.Table)

			model.Tags = GetTagMap(tagsResult.Tags)
			model.AccountId = accountId
			model.Region = region
			model.ReportTime = reportTime.UTC().UnixMilli()

			for _, f := range customTableDescriptionModelPostprocessingFuncs {
				f(ctx, client, cfg, model)
			}

			errors := storageContextSet.Store(ctx, model)
			for storageContext, err := range errors {
				storage.LogContextError(storageContext, fmt.Sprintf("Error storing TableDescriptionModel: %v", err))
			}
			numModels++
		}

	}

	return numModels, nil
}
