package elasticache

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticache"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomCacheClusterModelPostprocessingFunc(PostProcessCacheClusterModel)
}

func PostProcessCacheClusterModel(ctx context.Context, client *elasticache.Client, cfg aws.Config, model *CacheClusterModel) {
	if model.AuthTokenLastModifiedDate != nil {
		model.AuthTokenLastModifiedDateMilli = model.AuthTokenLastModifiedDate.UTC().UnixMilli()
	}
	if model.CacheClusterCreateTime != nil {
		model.CacheClusterCreateTimeMilli = model.CacheClusterCreateTime.UTC().UnixMilli()
	}

	for _, node := range model.CacheNodes {
		if node.CacheNodeCreateTime != nil {
			node.CacheNodeCreateTimeMilli = node.CacheNodeCreateTime.UTC().UnixMilli()
		}
	}

	tagResult, err := client.ListTagsForResource(ctx, &elasticache.ListTagsForResourceInput{
		ResourceName: aws.String(model.ARN),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "elasticache",
			"data_source": "cache_clusters",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListTagsForResource")
		return
	}

	model.Tags = GetTagMap(tagResult.TagList)
}
