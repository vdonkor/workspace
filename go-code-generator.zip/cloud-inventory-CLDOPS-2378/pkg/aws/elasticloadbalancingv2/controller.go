package elasticloadbalancingv2

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2"
	"github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2/types"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = ElasticLoadBalancingV2Controller{
		DataSources: map[string]func(ctx context.Context, client *elasticloadbalancingv2.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type ElasticLoadBalancingV2Controller struct {
	DataSources map[string]func(ctx context.Context, client *elasticloadbalancingv2.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (e *ElasticLoadBalancingV2Controller) GetRegionOverrides() []string {
	return []string{}
}

func (e *ElasticLoadBalancingV2Controller) GetName() string {
	return "elasticloadbalancingv2"
}

func (e *ElasticLoadBalancingV2Controller) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, client *elasticloadbalancingv2.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	e.DataSources[dataSourceName] = dataSourceFunc
}

func (e *ElasticLoadBalancingV2Controller) Process(ctx context.Context, accountId, region string, reportTime time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error) {
	elasticloadbalancingv2Client := elasticloadbalancingv2.NewFromConfig(cfg)

	errMap := map[string]error{}
	summaries := []meta.AwsResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range e.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "aws",
			Service:    "elasticloadbalancingv2",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, elasticloadbalancingv2Client, cfg, accountId, region, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		summary := meta.AwsResourceSummaryModel{
			Region:     region,
			AccountId:  accountId,
			Service:    "elasticloadbalancingv2",
			Resource:   dataSourceName,
			ReportTime: reportTime.UTC().UnixMilli(),
			Count:      count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":       "aws",
			"service":     "elasticloadbalancingv2",
			"region":      region,
			"account_id":  accountId,
			"datasource":  dataSourceName,
			"report_time": reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}

func GetTagMap(tags []types.Tag) map[string]string {
	tagMap := make(map[string]string)
	for _, tag := range tags {
		tagMap[*tag.Key] = *tag.Value
	}
	return tagMap
}
