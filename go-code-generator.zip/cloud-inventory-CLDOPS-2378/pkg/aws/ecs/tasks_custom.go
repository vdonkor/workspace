package ecs

import (
	"context"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ecs"
	"github.com/aws/aws-sdk-go-v2/service/ecs/types"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

func TaskDataSource(ctx context.Context, client *ecs.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(TaskModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	paginator := ecs.NewListClustersPaginator(client, &ecs.ListClustersInput{
		MaxResults: aws.Int32(100),
	})

	for paginator.HasMorePages() {
		output, err := paginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     storageConfig.Service,
				"data_source": storageConfig.DataSource,
				"account_id":  accountId,
				"region":      region,
				"cloud":       storageConfig.Cloud,
				"error":       err,
			}).Error("error calling ListClusters")
			return numModels, err
		}

		result, err := client.DescribeClusters(ctx, &ecs.DescribeClustersInput{
			Clusters: output.ClusterArns,
			Include:  []types.ClusterField{types.ClusterFieldAttachments, types.ClusterFieldConfigurations, types.ClusterFieldSettings, types.ClusterFieldStatistics, types.ClusterFieldTags},
		})
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     storageConfig.Service,
				"data_source": storageConfig.DataSource,
				"account_id":  accountId,
				"region":      region,
				"cloud":       storageConfig.Cloud,
				"error":       err,
			}).Error("error calling DescribeClusters")
			return numModels, err
		}
		for _, cluster := range result.Clusters {
			paginator := ecs.NewListTasksPaginator(client, &ecs.ListTasksInput{
				MaxResults: aws.Int32(100),
				Cluster:    cluster.ClusterName,
			})

			for paginator.HasMorePages() {
				output, err := paginator.NextPage(ctx)
				if err != nil {
					logrus.WithFields(logrus.Fields{
						"service":     storageConfig.Service,
						"data_source": storageConfig.DataSource,
						"account_id":  accountId,
						"region":      region,
						"cloud":       storageConfig.Cloud,
						"error":       err,
					}).Error("error calling ListTasks")
					return numModels, err
				}

				if len(output.TaskArns) == 0 {
					continue
				}

				result, err := client.DescribeTasks(ctx, &ecs.DescribeTasksInput{
					Tasks:   output.TaskArns,
					Cluster: cluster.ClusterName,
					Include: []types.TaskField{
						types.TaskFieldTags,
					},
				})
				if err != nil {
					logrus.WithFields(logrus.Fields{
						"service":     storageConfig.Service,
						"data_source": storageConfig.DataSource,
						"account_id":  accountId,
						"region":      region,
						"cloud":       storageConfig.Cloud,
						"error":       err,
					}).Error("error calling DescribeTasks")
					return numModels, err
				}
				for _, service := range result.Tasks {

					model := new(TaskModel)
					copier.Copy(&model, &service)

					model.Tags = GetTagMap(service.Tags)
					model.AccountId = accountId
					model.Region = region
					model.ReportTime = reportTime.UTC().UnixMilli()

					for _, f := range customTaskModelPostprocessingFuncs {
						f(ctx, client, cfg, model)
					}

					errors := storageContextSet.Store(ctx, model)
					for storageContext, err := range errors {
						storage.LogContextError(storageContext, fmt.Sprintf("Error storing TaskModel: %v", err))
					}
					numModels++
				}

			}
		}
	}

	return numModels, nil
}
