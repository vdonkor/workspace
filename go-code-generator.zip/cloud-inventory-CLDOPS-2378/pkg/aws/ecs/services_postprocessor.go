package ecs

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/ecs"
)

func init() {
	registerCustomServiceModelPostprocessingFunc(PostProcessServiceModel)
}

func PostProcessServiceModel(ctx context.Context, client *ecs.Client, cfg aws.Config, model *ServiceModel) {
	if model.CreatedAt != nil {
		model.CreatedAtMilli = model.CreatedAt.UTC().UnixMilli()
	}

	for _, deployment := range model.Deployments {
		if deployment.CreatedAt != nil {
			deployment.CreatedAtMilli = deployment.CreatedAt.UTC().UnixMilli()
		}

		if deployment.UpdatedAt != nil {
			deployment.UpdatedAtMilli = deployment.UpdatedAt.UTC().UnixMilli()
		}
	}

	for _, taskSet := range model.TaskSets {
		if taskSet.CreatedAt != nil {
			taskSet.CreatedAtMilli = taskSet.CreatedAt.UTC().UnixMilli()
		}

		if taskSet.StabilityStatusAt != nil {
			taskSet.StabilityStatusAtMilli = taskSet.StabilityStatusAt.UTC().UnixMilli()
		}

		if taskSet.UpdatedAt != nil {
			taskSet.UpdatedAtMilli = taskSet.UpdatedAt.UTC().UnixMilli()
		}
	}
}
