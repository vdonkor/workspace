package sns

import (
	"context"
	"strconv"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/sns"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomTopicModelPostprocessingFunc(PostProcessTopicModel)
}

func PostProcessTopicModel(ctx context.Context, client *sns.Client, cfg aws.Config, model *TopicModel) {
	attributeResult, err := client.GetTopicAttributes(ctx, &sns.GetTopicAttributesInput{
		TopicArn: aws.String(model.TopicArn),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "sns",
			"data_source": "topics",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling GetTopicAttributes")
		return
	}

	for key, value := range attributeResult.Attributes {
		switch key {
		case "DeliveryPolicy":
			model.DeliveryPolicy = value
		case "DisplayName":
			model.DisplayName = value
		case "Owner":
			model.Owner = value
		case "Policy":
			model.Policy = value
		case "SubscriptionsConfirmed":
			model.SubscriptionsConfirmed, err = strconv.Atoi(value)
			if err != nil {
				continue
			}
		case "SubscriptionsDeleted":
			model.SubscriptionsDeleted, err = strconv.Atoi(value)
			if err != nil {
				continue
			}
		case "SubscriptionsPending":
			model.SubscriptionsConfirmed, err = strconv.Atoi(value)
			if err != nil {
				continue
			}
		case "EffectiveDeliveryPolicy":
			model.EffectiveDeliveryPolicy = value
		case "KmsMasterKeyId":
			model.KmsMasterKeyId = value
		case "FifoTopic":
			model.FifoTopic = true
		case "ContentBasedDeduplication":
			if value == "true" {
				model.ContentBasedDeduplication = true
			}
		}
	}

	tagsResult, err := client.ListTagsForResource(ctx, &sns.ListTagsForResourceInput{
		ResourceArn: aws.String(model.TopicArn),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "sns",
			"data_source": "topics",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListTagsForResource")
		return
	}

	model.Tags = GetTagMap(tagsResult.Tags)
}
