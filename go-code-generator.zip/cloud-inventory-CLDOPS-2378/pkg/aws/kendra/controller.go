package kendra

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	kendra "github.com/aws/aws-sdk-go-v2/service/kendra"
	kendraType "github.com/aws/aws-sdk-go-v2/service/kendra/types"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = kendraController{
		DataSources: map[string]func(ctx context.Context, client *kendra.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type kendraController struct {
	DataSources map[string]func(ctx context.Context, client *kendra.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (e *kendraController) GetRegionOverrides() []string {
	return []string{"us-east-1"}
}

func (e *kendraController) GetName() string {
	return "kendra"
}

func (e *kendraController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, client *kendra.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	e.DataSources[dataSourceName] = dataSourceFunc
}

func (e *kendraController) Process(ctx context.Context, accountId, region string, reportTime time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error) {
	kendraClient := kendra.NewFromConfig(cfg)

	errMap := map[string]error{}
	summaries := []meta.AwsResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range e.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "aws",
			Service:    "kendra",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, kendraClient, cfg, accountId, region, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
			logrus.WithFields(logrus.Fields{
				"cloud":       "aws",
				"service":     "kendra",
				"region":      region,
				"account_id":  accountId,
				"datasource":  dataSourceName,
				"report_time": reportTime,
				"err":         err,
			}).Error("error processing data source")
		}
		summary := meta.AwsResourceSummaryModel{
			Region:     region,
			AccountId:  accountId,
			Service:    "kendra",
			Resource:   dataSourceName,
			ReportTime: reportTime.UTC().UnixMilli(),
			Count:      count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":       "aws",
			"service":     "kendra",
			"region":      region,
			"account_id":  accountId,
			"datasource":  dataSourceName,
			"report_time": reportTime,
			"count":       count,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}

func GetTagMap(tags []kendraType.Tag) map[string]string {
	tagMap := make(map[string]string)
	for _, tag := range tags {
		tagMap[*tag.Key] = *tag.Value
	}
	return tagMap
}
