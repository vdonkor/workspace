package iam

import (
	"context"
	"errors"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	"github.com/aws/smithy-go"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomUserModelPostprocessingFunc(PostProcessUserModel)
}

func PostProcessUserModel(ctx context.Context, client *iam.Client, cfg aws.Config, model *UserModel) {
	if model.CreateDate != nil {
		model.CreateDateMilli = model.CreateDate.UTC().UnixMilli()
	}

	if model.PasswordLastUsed != nil {
		model.PasswordLastUsedMilli = model.PasswordLastUsed.UTC().UnixMilli()
	}

	listAttachedUserPoliciesPaginator := iam.NewListAttachedUserPoliciesPaginator(client, &iam.ListAttachedUserPoliciesInput{
		UserName: aws.String(model.UserName),
	})

	for listAttachedUserPoliciesPaginator.HasMorePages() {
		output, err := listAttachedUserPoliciesPaginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     "iam",
				"data_source": "users",
				"account_id":  model.AccountId,
				"region":      model.Region,
				"cloud":       "aws",
				"error":       err,
			}).Error("error calling ListAttachedUserPolicies")
			break
		}

		for _, policy := range output.AttachedPolicies {
			policyModel := new(AttachedPolicyUserModel)
			copier.Copy(policyModel, policy)
			model.AttachedPolicies = append(model.AttachedPolicies, policyModel)
		}
	}

	//populate inline policies
	listUserPoliciesPaginator := iam.NewListUserPoliciesPaginator(client, &iam.ListUserPoliciesInput{
		UserName: aws.String(model.UserName),
	})

	for listUserPoliciesPaginator.HasMorePages() {
		output, err := listUserPoliciesPaginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     "iam",
				"data_source": "users",
				"account_id":  model.AccountId,
				"region":      model.Region,
				"cloud":       "aws",
				"error":       err,
			}).Error("error calling ListUserPolicies")
			break
		}

		model.InlinePolicies = append(model.InlinePolicies, output.PolicyNames...)
	}

	//populate associated groups
	listGroupsForUserPaginator := iam.NewListGroupsForUserPaginator(client, &iam.ListGroupsForUserInput{
		UserName: aws.String(model.UserName),
	})

	for listGroupsForUserPaginator.HasMorePages() {
		output, err := listGroupsForUserPaginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     "iam",
				"data_source": "users",
				"account_id":  model.AccountId,
				"region":      model.Region,
				"cloud":       "aws",
				"error":       err,
			}).Error("error calling ListGroupsForUser")
			break
		}

		for _, group := range output.Groups {
			model.GroupIds = append(model.GroupIds, *group.GroupId)
		}
	}

	// populate access keys
	model.AccessKeys = make([]*AccessKeyMetadataUserModel, 0)
	listAccessKeysPaginator := iam.NewListAccessKeysPaginator(client, &iam.ListAccessKeysInput{
		UserName: aws.String(model.UserName),
	})

	for listAccessKeysPaginator.HasMorePages() {
		output, err := listAccessKeysPaginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     "iam",
				"data_source": "users",
				"account_id":  model.AccountId,
				"region":      model.Region,
				"cloud":       "aws",
				"error":       err,
			}).Error("error calling ListAccessKeys")
			break
		}

		for _, key := range output.AccessKeyMetadata {
			accessKeyModel := new(AccessKeyMetadataUserModel)
			copier.Copy(accessKeyModel, &key)

			if accessKeyModel.CreateDate != nil {
				accessKeyModel.CreateDateMilli = accessKeyModel.CreateDate.UTC().UnixMilli()
			}

			model.AccessKeys = append(model.AccessKeys, accessKeyModel)
		}
	}

	// get login profile
	var apiError smithy.APIError

	profileResult, err := client.GetLoginProfile(ctx, &iam.GetLoginProfileInput{
		UserName: aws.String(model.UserName),
	})

	if errors.As(err, &apiError) && apiError.ErrorCode() == "NoSuchEntity" {
		// do nothing
	} else if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "iam",
			"data_source": "users",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling GetLoginProfile")
		return
	} else {
		loginProfileModel := new(LoginProfileUserModel)
		copier.Copy(loginProfileModel, profileResult.LoginProfile)

		if loginProfileModel.CreateDate != nil {
			loginProfileModel.CreateDateMilli = loginProfileModel.CreateDate.UTC().UnixMilli()
		}

		model.LoginProfile = loginProfileModel
	}

	// populate tags
	tagsResult, err := client.ListUserTags(ctx, &iam.ListUserTagsInput{
		UserName: aws.String(model.UserName),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "iam",
			"data_source": "users",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListUserTags")
		return
	}
	model.Tags = GetTagMap(tagsResult.Tags)
}
