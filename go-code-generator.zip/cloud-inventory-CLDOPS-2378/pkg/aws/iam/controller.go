package iam

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsiam "github.com/aws/aws-sdk-go-v2/service/iam"
	iamtypes "github.com/aws/aws-sdk-go-v2/service/iam/types"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

var (
	Controller = IamController{
		DataSources: map[string]func(ctx context.Context, client *awsiam.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error){},
	}
)

type IamController struct {
	DataSources map[string]func(ctx context.Context, client *awsiam.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)
}

func (e *IamController) GetRegionOverrides() []string {
	return []string{"us-east-1"}
}

func (e *IamController) GetName() string {
	return "iam"
}

func (e *IamController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, client *awsiam.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error)) {
	e.DataSources[dataSourceName] = dataSourceFunc
}

func (e *IamController) Process(ctx context.Context, accountId, region string, reportTime time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error) {
	iamClient := awsiam.NewFromConfig(cfg)

	errMap := map[string]error{}
	summaries := []meta.AwsResourceSummaryModel{}

	for dataSourceName, dataSourceFunc := range e.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "aws",
			Service:    "iam",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		count, err := dataSourceFunc(ctx, iamClient, cfg, accountId, region, reportTime, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		summary := meta.AwsResourceSummaryModel{
			Region:     region,
			AccountId:  accountId,
			Service:    "iam",
			Resource:   dataSourceName,
			ReportTime: reportTime.UTC().UnixMilli(),
			Count:      count,
		}
		summaries = append(summaries, summary)
		logrus.WithFields(logrus.Fields{
			"cloud":       "aws",
			"service":     "iam",
			"region":      region,
			"account_id":  accountId,
			"datasource":  dataSourceName,
			"report_time": reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return summaries, nil
	} else {
		return summaries, errMap
	}
}

func GetTagMap(tags []iamtypes.Tag) map[string]string {
	tagMap := make(map[string]string)
	for _, tag := range tags {
		tagMap[*tag.Key] = *tag.Value
	}
	return tagMap
}
