package iam

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iam"
)

func init() {
	registerCustomPolicyModelPostprocessingFunc(PostProcessPolicyModel)
}

func PostProcessPolicyModel(ctx context.Context, client *iam.Client, cfg aws.Config, model *PolicyModel) {
	if model.CreateDate != nil {
		model.CreateDateMilli = model.CreateDate.UTC().UnixMilli()
	}

	if model.UpdateDate != nil {
		model.UpdateDateMilli = model.UpdateDate.UTC().UnixMilli()
	}
}
