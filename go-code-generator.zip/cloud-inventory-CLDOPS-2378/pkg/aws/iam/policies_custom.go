package iam

import (
	"fmt"
	"time"

	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"

	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	"github.com/aws/aws-sdk-go-v2/service/iam/types"
)

func PolicyDataSource(ctx context.Context, client *iam.Client, cfg aws.Config, accountId, region string, reportTime time.Time, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) (int, error) {
	numModels := 0
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(PolicyModel))
	if err != nil {
		return numModels, err
	}
	defer storageContextSet.Close(ctx)

	paginator := iam.NewListPoliciesPaginator(client, &iam.ListPoliciesInput{
		Scope: types.PolicyScopeTypeLocal,
	})

	for paginator.HasMorePages() {
		output, err := paginator.NextPage(ctx)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"service":     storageConfig.Service,
				"data_source": storageConfig.DataSource,
				"account_id":  accountId,
				"region":      region,
				"cloud":       storageConfig.Cloud,
				"error":       err,
			}).Error("error calling ListPolicies")
			return numModels, err
		}

		for _, var0 := range output.Policies {

			model := new(PolicyModel)
			copier.Copy(&model, &var0)

			model.Tags = GetTagMap(var0.Tags)
			model.AccountId = accountId
			model.Region = region
			model.ReportTime = reportTime.UTC().UnixMilli()

			for _, f := range customPolicyModelPostprocessingFuncs {
				f(ctx, client, cfg, model)
			}

			errors := storageContextSet.Store(ctx, model)
			for storageContext, err := range errors {
				storage.LogContextError(storageContext, fmt.Sprintf("Error storing PolicyModel: %v", err))
			}
			numModels++
		}

	}

	return numModels, nil
}
