package redshift

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/redshift"
)

func init() {
	registerCustomClusterModelPostprocessingFunc(PostProcessClusterModel)
}

func PostProcessClusterModel(ctx context.Context, client *redshift.Client, cfg aws.Config, model *ClusterModel) {
	if model.ClusterCreateTime != nil {
		model.ClusterCreateTimeMilli = model.ClusterCreateTime.UTC().UnixMilli()
	}

	if model.ExpectedNextSnapshotScheduleTime != nil {
		model.ExpectedNextSnapshotScheduleTimeMilli = model.ExpectedNextSnapshotScheduleTime.UTC().UnixMilli()
	}

	if model.NextMaintenanceWindowStartTime != nil {
		model.NextMaintenanceWindowStartTimeMilli = model.NextMaintenanceWindowStartTime.UTC().UnixMilli()
	}

	for _, deferredMaintenanceWindow := range model.DeferredMaintenanceWindows {
		if deferredMaintenanceWindow.DeferMaintenanceEndTime != nil {
			deferredMaintenanceWindow.DeferMaintenanceEndTimeMilli = deferredMaintenanceWindow.DeferMaintenanceEndTime.UTC().UnixMilli()
		}
		if deferredMaintenanceWindow.DeferMaintenanceStartTime != nil {
			deferredMaintenanceWindow.DeferMaintenanceStartTimeMilli = deferredMaintenanceWindow.DeferMaintenanceStartTime.UTC().UnixMilli()
		}
	}
}
