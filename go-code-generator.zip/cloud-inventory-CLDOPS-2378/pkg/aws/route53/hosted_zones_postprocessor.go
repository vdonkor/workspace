package route53

import (
	"context"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/route53"
	"github.com/aws/aws-sdk-go-v2/service/route53/types"
	"github.com/jinzhu/copier"
	"github.com/sirupsen/logrus"
)

func init() {
	registerCustomHostedZoneModelPostprocessingFunc(PostProcessHostedZoneModel)
}

func PostProcessHostedZoneModel(ctx context.Context, client *route53.Client, cfg aws.Config, model *HostedZoneModel) {
	// get associated VPCs
	result, err := client.GetHostedZone(ctx, &route53.GetHostedZoneInput{
		Id: aws.String(model.Id),
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "route53",
			"data_source": "hosted_zones",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling GetHostedZone")
		return
	}
	model.VpcAssociations = make([]*VPCHostedZoneModel, len(result.VPCs))

	for i, vpc := range result.VPCs {
		vpcModel := new(VPCHostedZoneModel)
		copier.Copy(vpcModel, &vpc)
		model.VpcAssociations[i] = vpcModel
	}

	hosetdZoneIdParts := strings.Split(model.Id, "/")
	if len(hosetdZoneIdParts) != 3 {
		return
	}

	// get tags
	tagResult, err := client.ListTagsForResource(ctx, &route53.ListTagsForResourceInput{
		ResourceId:   aws.String(hosetdZoneIdParts[2]),
		ResourceType: types.TagResourceTypeHostedzone,
	})
	if err != nil {
		logrus.WithFields(logrus.Fields{
			"service":     "route53",
			"data_source": "hosted_zones",
			"account_id":  model.AccountId,
			"region":      model.Region,
			"cloud":       "aws",
			"error":       err,
		}).Error("error calling ListTagsForResource")
		return
	}

	if tagResult.ResourceTagSet != nil {
		model.Tags = GetTagMap(tagResult.ResourceTagSet.Tags)
	}
}
