package performancedata

import (
	"context"
	"strings"
	"time"

	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
)

var (
	Controller = PerformanceDataController{
		DataSources: map[string]func(ctx context.Context, reportTime time.Time, authUsername, authPassword string, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) error{},
	}
)

type PerformanceDataController struct {
	DataSources map[string]func(ctx context.Context, reportTime time.Time, authUsername, authPassword string, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) error
}

func (c *PerformanceDataController) GetName() string {
	return "network"
}

func (c *PerformanceDataController) RegisterDataSource(dataSourceName string, dataSourceFunc func(ctx context.Context, reportTime time.Time, authUsername, authPassword string, storageConfig storage.StorageContextConfig, storageManager *storage.StorageManager) error) {
	c.DataSources[dataSourceName] = dataSourceFunc
}

func (c *PerformanceDataController) Process(ctx context.Context, reportTime time.Time, authUsername, authPassword string, storageManager *storage.StorageManager) map[string]error {
	errMap := map[string]error{}

	for dataSourceName, dataSourceFunc := range c.DataSources {
		storageConfig := storage.StorageContextConfig{
			Cloud:      "infraview",
			Service:    "performancedata",
			DataSource: dataSourceName,
			Date:       reportTime,
		}
		err := dataSourceFunc(ctx, reportTime, authUsername, authPassword, storageConfig, storageManager)
		if err != nil {
			errMap[dataSourceName] = err
		}
		logrus.WithFields(logrus.Fields{
			"cloud":       "infraview",
			"service":     "performancedata",
			"datasource":  dataSourceName,
			"report_time": reportTime,
		}).Info("processed data source")
	}

	if len(errMap) == 0 {
		return nil
	} else {
		return errMap
	}
}

func GetResourceGroupFromID(id string) string {
	parts := strings.Split(id, "/")
	return parts[4]
}
