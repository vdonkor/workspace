package performancedata

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strconv"
	"time"

	internalstorage "gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"

	"context"
	"sync"

	"github.com/Azure/go-autorest/autorest"
	"github.com/hashicorp/go-retryablehttp"
	"github.com/sirupsen/logrus"
)

var customMetricsModelPostprocessingFuncs []func(ctx context.Context, authorizer autorest.Authorizer, x *MetricsModel) = []func(ctx context.Context, authorizer autorest.Authorizer, x *MetricsModel){}
var customMetricsModelFuncsLock sync.Mutex

var metricIDs map[string]string = map[string]string{
	"vm_cores":     "17643",
	"vm_disk_size": "17645",
	"vm_servers":   "17633",
	"vm_ram":       "17644",
}

var infraviewURLFormat string = "https://infraview.epa.gov/api/device/2473/performance_data/%s/data?duration=2h"

func registerCustomMetricsModelPostprocessingFunc(f func(ctx context.Context, authorizer autorest.Authorizer, x *MetricsModel)) {
	customMetricsModelFuncsLock.Lock()
	defer customMetricsModelFuncsLock.Unlock()

	customMetricsModelPostprocessingFuncs = append(customMetricsModelPostprocessingFuncs, f)
}

func init() {
	Controller.RegisterDataSource("metrics", MetricsDataSource)
}

type MetricsModel struct {
	VmCores      float64 `parquet:"name=vm_cores,type=DOUBLE"`
	VmDiskSizeGB float64 `parquet:"name=vm_disk_size_gb,type=DOUBLE"`
	VmServers    float64 `parquet:"name=vm_servers,type=DOUBLE"`
	VmMemoryGB   float64 `parquet:"name=vm_memory_gb,type=DOUBLE"`
	ReportTime   int64   `parquet:"name=report_time,type=INT64,convertedtype=TIMESTAMP_MILLIS"`
}

type InfraviewResponseModel struct {
	Data map[string]map[string]string `json:"data"`
}

func MetricsDataSource(ctx context.Context, reportTime time.Time, authUsername, authPassword string, storageConfig internalstorage.StorageContextConfig, storageManager *internalstorage.StorageManager) error {
	storageContextSet, err := storageManager.GetStorageContextSet(storageConfig, new(MetricsModel))
	if err != nil {
		return err
	}
	defer storageContextSet.Close(ctx)

	client := retryablehttp.NewClient()
	model := new(MetricsModel)
	model.ReportTime = reportTime.UTC().UnixMilli()

	for key, value := range metricIDs {
		req, err := retryablehttp.NewRequest("GET", fmt.Sprintf(infraviewURLFormat, value), nil)
		if err != nil {
			return err
		}

		req.SetBasicAuth(authUsername, authPassword)

		resp, err := client.Do(req)
		if err != nil {
			return err
		}

		if resp.StatusCode != 200 {
			return errors.New("got non-200 status code from infraview")
		}

		buf := bytes.NewBuffer([]byte{})
		_, err = io.Copy(buf, resp.Body)
		if err != nil {
			return err
		}

		responseData := new(InfraviewResponseModel)
		err = json.Unmarshal(buf.Bytes(), &responseData)
		if err != nil {
			logrus.WithFields(logrus.Fields{
				"err": err,
			}).Error("error unmarshaling HTTP response")
			return err
		}

		timeData, ok := responseData.Data["0"]
		if !ok {
			return errors.New("unknown response format from infraview")
		}
		var datapoint float64
		for _, datapointString := range timeData {
			datapoint, err = strconv.ParseFloat(datapointString, 64)
			if err != nil {
				logrus.WithFields(logrus.Fields{
					"err": err,
				}).Error("error converting datapoint to int")
				return err
			}
			break
		}

		switch key {
		case "vm_cores":
			model.VmCores = datapoint
		case "vm_disk_size":
			model.VmDiskSizeGB = datapoint * 1024
		case "vm_servers":
			model.VmServers = datapoint
		case "vm_ram":
			model.VmMemoryGB = datapoint
		}
	}

	errors := storageContextSet.Store(ctx, model)
	for storageContext, err := range errors {
		internalstorage.LogContextError(storageContext, fmt.Sprintf("Error storing MetricsModel: %v", err))
	}

	return nil
}
