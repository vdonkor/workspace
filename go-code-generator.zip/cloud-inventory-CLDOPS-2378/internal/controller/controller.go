package controller

import (
	"context"
	"time"

	"github.com/Azure/go-autorest/autorest"
	"github.com/aws/aws-sdk-go-v2/aws"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

type AwsController interface {
	Process(ctx context.Context, accountId, region string, date time.Time, cfg aws.Config, storageManager *storage.StorageManager) ([]meta.AwsResourceSummaryModel, map[string]error)
	GetName() string
	GetRegionOverrides() []string
}

type CustomController interface {
	Process(ctx context.Context, date time.Time, cfg aws.Config, storageManager *storage.StorageManager) map[string]error
}

type AzureController interface {
	Process(ctx context.Context, subscriptionId string, date time.Time, authorizer autorest.Authorizer, storageManager *storage.StorageManager) ([]meta.AzureResourceSummaryModel, map[string]error)
	GetName() string
}

type InfraviewController interface {
	Process(ctx context.Context, date time.Time, authUsername, authPassword string, storageManager *storage.StorageManager) map[string]error
}
