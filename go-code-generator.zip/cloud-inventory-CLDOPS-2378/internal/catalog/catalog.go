package catalog

import (
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/controller"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/backup"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/cloudwatchlogs"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/dynamodb"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/ec2"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/ecs"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/efs"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/elasticache"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/elasticloadbalancing"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/elasticloadbalancingv2"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/emr"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/iam"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/kendra"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/lambda"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/rds"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/redshift"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/route53"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/s3"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/sns"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/sqs"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/aws/storagegateway"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/compute"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/network"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/operationalinsights"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/resources"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/sql"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/azure/subscription"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/accountinventory"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/infraview/performancedata"
)

var (
	AwsServiceControllers = []controller.AwsController{
		&backup.Controller,
		&cloudwatchlogs.Controller,
		&dynamodb.Controller,
		&ec2.Controller,
		&ecs.Controller,
		&efs.Controller,
		&elasticache.Controller,
		&elasticloadbalancing.Controller,
		&elasticloadbalancingv2.Controller,
		&iam.Controller,
		&lambda.Controller,
		&rds.Controller,
		&redshift.Controller,
		&route53.Controller,
		&s3.Controller,
		&sns.Controller,
		&sqs.Controller,
		&storagegateway.Controller,
		&emr.Controller,
		&kendra.Controller,
	}

	AzureServiceControllers = []controller.AzureController{
		&compute.Controller,
		&resources.Controller,
		&network.Controller,
		&storage.Controller,
		&sql.Controller,
		&operationalinsights.Controller,
	}

	InfraviewServiceControllers = []controller.InfraviewController{
		&performancedata.Controller,
	}

	DatasourceModels = map[string]map[string]map[string]interface{}{

		"aws": {
			"backup": {
				"vaults": new(backup.BackupVaultListMemberModel),
				"plans":  new(backup.BackupPlansListMemberModel),
			},
			"cloudwatchlogs": {
				"log_groups": new(cloudwatchlogs.LogGroupModel),
			},
			"dynamodb": {
				"tables": new(dynamodb.TableDescriptionModel),
			},
			"ec2": {
				"instances":                           new(ec2.InstanceModel),
				"volumes":                             new(ec2.VolumeModel),
				"vpcs":                                new(ec2.VpcModel),
				"subnets":                             new(ec2.SubnetModel),
				"network_interfaces":                  new(ec2.NetworkInterfaceModel),
				"dhcp_options":                        new(ec2.DhcpOptionsModel),
				"internet_gateways":                   new(ec2.InternetGatewayModel),
				"managed_prefix_lists":                new(ec2.ManagedPrefixListModel),
				"nat_gateways":                        new(ec2.NatGatewayModel),
				"network_acls":                        new(ec2.NetworkAclModel),
				"route_tables":                        new(ec2.RouteTableModel),
				"security_groups":                     new(ec2.SecurityGroupModel),
				"transit_gateways":                    new(ec2.TransitGatewayModel),
				"transit_gateway_route_tables":        new(ec2.TransitGatewayRouteTableModel),
				"transit_gateway_vpc_attachments":     new(ec2.TransitGatewayVpcAttachmentModel),
				"transit_gateway_peering_attachments": new(ec2.TransitGatewayPeeringAttachmentModel),
				"vpc_endpoints":                       new(ec2.VpcEndpointModel),
				"vpc_peering_connections":             new(ec2.VpcPeeringConnectionModel),
				"vpn_gateways":                        new(ec2.VpnGatewayModel),
				"reserved_instances":                  new(ec2.ReservedInstancesModel),
				"placement_groups":                    new(ec2.PlacementGroupModel),
				"addresses":                           new(ec2.AddressModel),
				"images":                              new(ec2.ImageModel),
				"instance_types":                      new(ec2.InstanceTypeInfoModel),
			},
			"ecs": {
				"clusters": new(ecs.ClusterModel),
				"services": new(ecs.ServiceModel),
				"tasks":    new(ecs.TaskModel),
			},
			"emr": {
				"clusters": new(emr.ClusterSummaryModel),
			},
			"efs": {
				"filesystems": new(efs.FileSystemDescriptionModel),
			},
			"eks": {},
			"elasticache": {
				"cache_clusters": new(elasticache.CacheClusterModel),
			},
			"elasticloadbalancing": {
				"load_balancers": new(elasticloadbalancing.LoadBalancerDescriptionModel),
			},
			"elasticloadbalancingv2": {
				"load_balancers": new(elasticloadbalancingv2.LoadBalancerModel),
				"target_groups":  new(elasticloadbalancingv2.TargetGroupModel),
			},
			"iam": {
				"roles":             new(iam.RoleModel),
				"policies":          new(iam.PolicyModel),
				"users":             new(iam.UserModel),
				"groups":            new(iam.GroupModel),
				"instance_profiles": new(iam.InstanceProfileModel),
			},
			"kendra": {
				"indexes": new(kendra.IndexConfigurationSummaryModel),
			},
			"lambda": {
				"functions": new(lambda.FunctionConfigurationModel),
			},
			"rds": {
				"db_clusters":  new(rds.DBClusterModel),
				"db_instances": new(rds.DBInstanceModel),
			},
			"redshift": {
				"clusters": new(redshift.ClusterModel),
			},
			"route53": {
				"hosted_zones": new(route53.HostedZoneModel),
			},
			"s3": {
				"buckets": new(s3.BucketModel),
			},
			"sns": {
				"topics":        new(sns.TopicModel),
				"subscriptions": new(sns.SubscriptionModel),
			},
			"sqs": {
				"queues": new(sqs.QueueModel),
			},
			"storagegateway": {
				"gateways": new(storagegateway.DescribeGatewayInformationOutputModel),
			},
		},
		"custom": {
			"accountinventory": {
				"accounts": new(accountinventory.AccountModel),
			},
			"meta": {
				"aws_resource_summary":   new(meta.AwsResourceSummaryModel),
				"azure_resource_summary": new(meta.AzureResourceSummaryModel),
			},
		},
		"azure": {
			"compute": {
				"virtual_machines":              new(compute.VirtualMachineModel),
				"resource_skus":                 new(compute.ResourceSkuModel),
				"disks":                         new(compute.DiskModel),
				"virtual_machine_scale_sets":    new(compute.VirtualMachineScaleSetModel),
				"virtual_machine_scale_set_vms": new(compute.VirtualMachineScaleSetVMModel),
			},
			"resources": {
				"groups": new(resources.GroupModel),
			},
			"subscription": {
				"subscriptions": new(subscription.ModelModel),
			},
			"network": {
				"application_gateways":        new(network.ApplicationGatewayModel),
				"application_security_groups": new(network.ApplicationSecurityGroupModel),
				"interfaces":                  new(network.InterfaceModel),
				"load_balancers":              new(network.LoadBalancerModel),
				"route_tables":                new(network.RouteTableModel),
				"security_groups":             new(network.SecurityGroupModel),
				"virtual_networks":            new(network.VirtualNetworkModel),
			},
			"storage": {
				"accounts": new(storage.AccountModel),
			},
			"sql": {
				"servers":   new(sql.ServerModel),
				"databases": new(sql.DatabaseModel),
			},
			"operationalinsights": {
				"workspaces": new(operationalinsights.WorkspaceModel),
			},
		},
		"infraview": {
			"performancedata": {
				"metrics": new(performancedata.MetricsModel),
			},
		},
	}
)
