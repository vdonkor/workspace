package processor

import (
	"context"
	"sync"
	"time"

	"github.com/Azure/go-autorest/autorest"
	"github.com/sirupsen/logrus"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/controller"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/internal/storage"
	"gitlab.epa.gov/task7/infrastructure/cloud-inventory/pkg/custom/meta"
)

type AzureJob struct {
	controller     controller.AzureController
	ctx            context.Context
	subscriptionId string
	region         string
	date           time.Time
	authorizer     autorest.Authorizer
	storageManager *storage.StorageManager
}

func NewAzureJob(controller controller.AzureController, ctx context.Context, subscriptionId string, date time.Time, authorizer autorest.Authorizer, storageManager *storage.StorageManager) AzureJob {
	return AzureJob{
		controller:     controller,
		ctx:            ctx,
		subscriptionId: subscriptionId,
		date:           date,
		authorizer:     authorizer,
		storageManager: storageManager,
	}
}

func AzureJobWorker(jobChannel chan AzureJob, cancelChannel chan bool, summaryChannel chan []meta.AzureResourceSummaryModel, jobWaitGroup, workerWaitGroup *sync.WaitGroup) {
InfiniteLoop:
	for {
		select {
		case <-cancelChannel:
			logrus.Info("stopping AzureJobWorker")
			break InfiniteLoop
		case job := <-jobChannel:
			summaries, errors := job.controller.Process(job.ctx, job.subscriptionId, job.date, job.authorizer, job.storageManager)
			if errors != nil {
				for datasource, err := range errors {
					logrus.WithFields(logrus.Fields{
						"account_id": job.subscriptionId,
						"region":     job.region,
						"cloud":      "azure",
						"service":    job.controller.GetName(),
						"datasouce":  datasource,
						"error":      err,
					}).Error("Error processing datasource")
				}
			}
			summaryChannel <- summaries
			jobWaitGroup.Done()
		}
	}

	workerWaitGroup.Done()
}

type AzureJobProcessor struct {
	cancelChannels  []chan bool
	jobChannel      chan AzureJob
	summaryChannel  chan []meta.AzureResourceSummaryModel
	numWorkers      int
	jobWaitGroup    sync.WaitGroup
	jobBufferLength int
	workerWaitGroup sync.WaitGroup
}

func NewAzureJobProcessor(numWorkers, jobBufferLength int, summaryChannel chan []meta.AzureResourceSummaryModel) *AzureJobProcessor {
	a := AzureJobProcessor{
		numWorkers:      numWorkers,
		jobBufferLength: jobBufferLength,
		jobChannel:      make(chan AzureJob, jobBufferLength),
		summaryChannel:  summaryChannel,
	}
	a.cancelChannels = make([]chan bool, a.numWorkers)

	return &a
}

func (a *AzureJobProcessor) Start() {
	logrus.WithFields(logrus.Fields{
		"num_workers": a.numWorkers,
	}).Info("Starting Azure Job Processor")

	// spin up a worker
	for i := 0; i < a.numWorkers; i++ {
		a.cancelChannels[i] = make(chan bool)
		a.workerWaitGroup.Add(1)
		go AzureJobWorker(a.jobChannel, a.cancelChannels[i], a.summaryChannel, &a.jobWaitGroup, &a.workerWaitGroup)
	}
}

func (a *AzureJobProcessor) AddJob(job AzureJob) {
	a.jobWaitGroup.Add(1)
	a.jobChannel <- job
}

func (a *AzureJobProcessor) Cancel() {
	logrus.Info("cancelling Azure Job Processor")
	for i := 0; i < a.numWorkers; i++ {
		a.cancelChannels[i] <- true
	}
	a.workerWaitGroup.Wait()
	for i := 0; i < a.numWorkers; i++ {
		close(a.cancelChannels[i])
	}
}

func (a *AzureJobProcessor) WaitForCompletion() {
	logrus.Info("Stopping Azure Job Processor, waiting for jobs to complete")
	//wait for jobs to be complete, then cancel workers and wait for them to be done
	a.jobWaitGroup.Wait()
	logrus.Info("Stopping Azure Job Processor, waiting for workers to finish stopping")
	a.Cancel()
	close(a.jobChannel)
}
